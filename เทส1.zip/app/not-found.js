import Link from 'next/link';
export default function NotFound(){
  return <div className="auth"><div className="card" style={{textAlign:'center',maxWidth:420}}>
    <div className="big" style={{fontSize:56,fontWeight:700}}>404</div>
    <p className="mut">ไม่พบหน้าที่คุณต้องการ · Page not found</p>
    <p><Link className="btn" href="/">กลับหน้าแรก</Link></p>
  </div></div>;
}
