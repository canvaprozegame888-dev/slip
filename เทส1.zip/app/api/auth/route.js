import bcrypt from 'bcryptjs';
import {cookies} from 'next/headers';
import {db} from '@/lib/db';
import {setSession} from '@/lib/auth';
import {getSettings} from '@/lib/settings';
import {getShop} from '@/lib/shop';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';

const hits=globalThis.__authHits||(globalThis.__authHits=new Map());
const limited=k=>{const now=Date.now();const a=(hits.get(k)||[]).filter(t=>now-t<600000);hits.set(k,a);return a.length>=8};
const hit=k=>{if(hits.size>5000)hits.clear();hits.set(k,[...(hits.get(k)||[]),Date.now()])};

export async function POST(req){
  const b=await readBody(req);
  const ip=(req.headers.get('x-forwarded-for')||'').split(',')[0].trim()||'local';

  if(b.mode==='logout'){cookies().delete('s');return json({ok:true})}

  if(b.mode==='login'){
    const id=String(b.username||'').trim(),pw=String(b.password||'');
    if(!id||!pw)return fail('กรอกยูสเซอร์เนมและรหัสผ่าน');
    const key=ip+'|'+id.toLowerCase();
    if(limited(key))return fail('ลองเข้าสู่ระบบผิดหลายครั้ง กรุณารอ 10 นาทีแล้วลองใหม่',429);
    const col=id.includes('@')?'email':'username';
    const {data}=await db.from('users').select('id,password_hash,is_banned').eq(col,col==='email'?id.toLowerCase():id).limit(1);
    const u=data?.[0];
    if(!u||!(await bcrypt.compare(pw,u.password_hash))){hit(key);return fail('ยูสเซอร์เนมหรือรหัสผ่านไม่ถูกต้อง',401)}
    if(u.is_banned)return fail('บัญชีนี้ถูกระงับการใช้งาน',403);
    await setSession(u.id);
    return json({ok:true});
  }

  if(b.mode==='register'){
    const username=String(b.username||'').trim(),email=String(b.email||'').trim().toLowerCase(),phone=String(b.phone||'').replace(/\D/g,''),pw=String(b.password||'');
    if(!/^[A-Za-z0-9_.\-]{3,30}$/.test(username))return fail('ยูสเซอร์เนมต้องเป็น a-z 0-9 _ . - ยาว 3-30 ตัว');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return fail('อีเมลไม่ถูกต้อง');
    if(phone.length<9||phone.length>15)return fail('เบอร์โทรศัพท์ไม่ถูกต้อง');
    if(pw.length<8||pw.length>100)return fail('รหัสผ่านต้องยาวอย่างน้อย 8 ตัว');
    const key='reg|'+ip;
    if(limited(key))return fail('สมัครบ่อยเกินไป กรุณารอสักครู่',429);
    hit(key);
    for(const [col,val,msg] of [['username',username,'ยูสเซอร์เนมนี้ถูกใช้แล้ว'],['email',email,'อีเมลนี้ถูกใช้แล้ว'],['phone',phone,'เบอร์โทรนี้ถูกใช้แล้ว']]){
      const {data}=await db.from('users').select('id').eq(col,val).limit(1);
      if(data?.length)return fail(msg,409);
    }
    const {data:u,error}=await db.from('users').insert({username,email,phone,password_hash:await bcrypt.hash(pw,10)}).select('id').single();
    if(error||!u)return fail('สมัครสมาชิกไม่สำเร็จ ลองใหม่อีกครั้ง',500);
    try{
      const bonus=parseInt((await getSettings()).signup_bonus,10)||0;
      if(bonus>0)await db.rpc('add_credits',{p_uid:u.id,p_delta:bonus,p_reason:'เครดิตต้อนรับสมาชิกใหม่'});
      await getShop(u.id);
    }catch{}
    await setSession(u.id);
    return json({ok:true});
  }
  return fail('คำขอไม่ถูกต้อง');
}
