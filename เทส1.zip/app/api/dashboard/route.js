import {getUser} from '@/lib/auth';
import {db} from '@/lib/db';
import {getShop} from '@/lib/shop';
import {fillDays,sumDays,todayTH} from '@/lib/stats';
import {json} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  const u=await getUser();if(!u)return json({ok:false},401);
  const shop=await getShop(u.id);
  let rows=[],recent=[];
  if(shop){
    rows=(await db.rpc('daily_stats',{p_shop:shop.id})).data||[];
    recent=(await db.from('slips').select('id,trans_ref,amount,sender,receiver,status,reason,created_at').eq('shop_id',shop.id).order('created_at',{ascending:false}).limit(8)).data||[];
  }
  const today=rows.find(r=>r.d===todayTH());
  return json({ok:true,user:u,connected:!!(shop?.channel_secret&&shop?.channel_token),
    today:{ok:Number(today?.ok)||0,fail:Number(today?.fail)||0},month:sumDays(rows),daily:fillDays(rows,14),recent});
}
