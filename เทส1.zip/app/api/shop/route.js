import {getUser} from '@/lib/auth';
import {db} from '@/lib/db';
import {getShop} from '@/lib/shop';
import {THEMES} from '@/lib/flex';
import {splitNames} from '@/lib/names';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
const mask=s=>!s?'':s.length>=12?s.slice(0,4)+'••••••••'+s.slice(-4):'••••••••';
const view=s=>({id:s.id,name:s.name||'',channel_id:s.channel_id||'',secret:mask(s.channel_secret),token:mask(s.channel_token),has_secret:!!s.channel_secret,has_token:!!s.channel_token,
  receiver_names:s.receiver_names||[],allow_duplicate:!!s.allow_duplicate,theme_ok:s.theme_ok||'green',theme_fail:s.theme_fail||'red'});
const newVal=v=>{v=String(v||'').trim();return v&&!v.includes('•')?v:null};

export async function GET(){
  const u=await getUser();if(!u)return json({ok:false},401);
  const s=await getShop(u.id);if(!s)return fail('ไม่พบข้อมูลร้าน',500);
  return json({ok:true,shop:view(s)});
}

export async function POST(req){
  const u=await getUser();if(!u)return json({ok:false},401);
  const s=await getShop(u.id);if(!s)return fail('ไม่พบข้อมูลร้าน',500);
  const b=await readBody(req);

  if(b.mode==='test'){
    const token=newVal(b.token)||s.channel_token;
    if(!token)return fail('ยังไม่ได้ใส่ Channel access token');
    try{
      const r=await fetch('https://api.line.me/v2/bot/info',{headers:{Authorization:'Bearer '+token},signal:AbortSignal.timeout(8000)});
      const j=await r.json().catch(()=>({}));
      if(!r.ok)return fail('Token ไม่ถูกต้องหรือหมดอายุ ('+(j.message||r.status)+')');
      return json({ok:true,name:j.displayName||j.basicId||'LINE OA'});
    }catch{return fail('เชื่อมต่อ LINE ไม่สำเร็จ ลองใหม่อีกครั้ง')}
  }

  const upd={
    name:String(b.name||'').trim().slice(0,100),
    channel_id:String(b.channel_id||'').trim().slice(0,50),
    receiver_names:splitNames((Array.isArray(b.receiver_names)?b.receiver_names.join('\n'):b.receiver_names)).slice(0,20).map(x=>x.slice(0,100)),
    allow_duplicate:!!b.allow_duplicate,
    theme_ok:THEMES.ok[b.theme_ok]?b.theme_ok:'green',
    theme_fail:THEMES.fail[b.theme_fail]?b.theme_fail:'red'};
  const sec=newVal(b.channel_secret),tok=newVal(b.channel_token);
  if(sec)upd.channel_secret=sec;
  if(tok)upd.channel_token=tok;
  const {error}=await db.from('shops').update(upd).eq('id',s.id);
  if(error)return fail('บันทึกไม่สำเร็จ',500);
  return json({ok:true,shop:view({...s,...upd})});
}