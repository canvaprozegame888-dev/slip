import {getUser} from '@/lib/auth';
import {json} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  const u=await getUser();
  if(!u)return json({ok:false},401);
  return json(u);
}
