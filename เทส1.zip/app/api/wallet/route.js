import crypto from 'crypto';
import sharp from 'sharp';
import QRCode from 'qrcode';
import {getUser} from '@/lib/auth';
import {db} from '@/lib/db';
import {getSettings} from '@/lib/settings';
import {readQR,verifyQR} from '@/lib/verify';
import {nameMatch} from '@/lib/names';
import {promptpay} from '@/lib/promptpay';
import {json,fail,isDup} from '@/lib/http';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const sha=x=>crypto.createHash('sha256').update(String(x)).digest('hex');

export async function GET(req){
  const u=await getUser();if(!u)return json({ok:false},401);
  const s=await getSettings();
  const amount=Number(new URL(req.url).searchParams.get('amount'));
  let qr=null;
  if(s.pp_id&&amount>=1&&amount<=1000000)qr=await QRCode.toDataURL(promptpay(s.pp_id,amount),{margin:1,width:320}).catch(()=>null);
  const [tp,mv]=await Promise.all([
    db.from('topups').select('id,amount,status,note,created_at').eq('user_id',u.id).order('created_at',{ascending:false}).limit(30),
    db.from('wallet_logs').select('id,delta,reason,created_at').eq('user_id',u.id).order('created_at',{ascending:false}).limit(30)]);
  return json({ok:true,wallet:u.wallet,pp:{ok:!!s.pp_id,name:s.pp_name||''},qr,topups:tp.data||[],moves:mv.data||[]});
}

export async function POST(req){
  const u=await getUser();if(!u)return json({ok:false},401);
  let fd;try{fd=await req.formData()}catch{return fail('ส่งข้อมูลไม่ถูกต้อง')}
  const file=fd.get('file'),mode=fd.get('mode')==='manual'?'manual':'auto',amount=Number(fd.get('amount'));
  if(!file||typeof file==='string')return fail('กรุณาเลือกรูปสลิป');
  if(file.size>10e6)return fail('ไฟล์ใหญ่เกินไป (สูงสุด 10 MB)');
  const buf=Buffer.from(await file.arrayBuffer());
  try{await sharp(buf).metadata()}catch{return fail('ไฟล์ที่เลือกไม่ใช่รูปภาพ')}
  const qr=await readQR(buf).catch(()=>null);
  const hash=qr?sha(qr):null;

  if(mode==='manual'){
    if(!(amount>=1&&amount<=1000000))return fail('กรุณาใส่ยอดที่เติมให้ถูกต้อง');
    const {data:pend}=await db.from('topups').select('id').eq('user_id',u.id).eq('status','pending');
    if((pend?.length||0)>=5)return fail('มีรายการรอตรวจสอบหลายรายการแล้ว กรุณารอแอดมินอนุมัติก่อน');
    const img='data:image/jpeg;base64,'+(await sharp(buf).rotate().resize({width:900,withoutEnlargement:true}).jpeg({quality:60}).toBuffer()).toString('base64');
    const {error}=await db.from('topups').insert({user_id:u.id,amount,status:'pending',slip_img:img,qr_hash:hash,note:'รอแอดมินตรวจสอบ'});
    if(error)return fail(isDup(error)?'สลิปนี้ถูกส่งหรือถูกใช้ไปแล้ว':'บันทึกรายการไม่สำเร็จ',isDup(error)?409:500);
    return json({ok:true,pending:true});
  }

  // ----- ตรวจอัตโนมัติ -----
  if(!qr)return fail('ไม่พบ QR บนสลิป กรุณาส่งรูปสลิปที่ชัดเจน');
  const ins=await db.from('topups').insert({user_id:u.id,amount:0,status:'pending',qr_hash:hash,note:'กำลังตรวจสอบอัตโนมัติ'}).select('id').single();
  if(ins.error||!ins.data)return fail(isDup(ins.error)?'สลิปนี้ถูกใช้แล้ว':'ระบบขัดข้อง ลองใหม่อีกครั้ง',isDup(ins.error)?409:500);
  const id=ins.data.id,drop=async msg=>{await db.from('topups').delete().eq('id',id);return fail(msg)};
  const r=await verifyQR(qr).catch(()=>({ok:false,error:'ระบบตรวจสลิปขัดข้อง ลองใหม่อีกครั้ง'}));
  if(!r.ok)return drop(r.error);
  const s=await getSettings();
  if(s.pp_name&&!nameMatch(r.receiver,s.pp_name))return drop('ชื่อผู้รับในสลิปไม่ตรงกับบัญชีรับเงินของระบบ');
  const amt=Number(r.amount);
  if(!(amt>0))return drop('อ่านยอดเงินจากสลิปไม่ได้');
  const up=await db.from('topups').update({trans_ref:r.transRef,amount:amt,status:'approved',note:'ตรวจอัตโนมัติ · ผู้โอน '+(r.sender||'-'),reviewed_at:new Date().toISOString()}).eq('id',id);
  if(up.error)return drop(isDup(up.error)?'สลิปนี้ถูกใช้แล้ว':'บันทึกรายการไม่สำเร็จ');
  const w=await db.rpc('add_wallet',{p_uid:u.id,p_delta:amt,p_reason:'เติมเงินเข้ากระเป๋า (ตรวจสลิปอัตโนมัติ)'});
  if(w.data==null){await db.from('topups').update({status:'rejected',note:'เติมเงินเข้ากระเป๋าไม่สำเร็จ'}).eq('id',id);return fail('เติมเงินไม่สำเร็จ กรุณาติดต่อผู้ดูแล',500)}
  return json({ok:true,wallet:Number(w.data),amount:amt});
}
