import {adminOnly} from '@/lib/auth';
import {db} from '@/lib/db';
import {fillDays} from '@/lib/stats';
import {json,fail} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const [t,d]=await Promise.all([db.rpc('admin_totals'),db.rpc('daily_stats',{p_shop:null})]);
  return json({ok:true,totals:t.data||{},daily:fillDays(d.data||[],14)});
}
