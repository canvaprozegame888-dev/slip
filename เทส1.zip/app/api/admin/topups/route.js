import {adminOnly} from '@/lib/auth';
import {db} from '@/lib/db';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(req){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const q=new URL(req.url).searchParams,one=q.get('img');
  if(one){const {data}=await db.from('topups').select('slip_img').eq('id',Number(one)).limit(1);return json({ok:true,img:data?.[0]?.slip_img||null})}
  let s=db.from('topups').select('id,user_id,amount,trans_ref,status,note,created_at,reviewed_at,users(username,phone)');
  const st=q.get('status');if(st&&st!=='all')s=s.eq('status',st);
  const {data}=await s.order('created_at',{ascending:false}).limit(300);
  return json({ok:true,topups:data||[]});
}
export async function POST(req){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const b=await readBody(req),id=Number(b.id);
  const {data:rows}=await db.from('topups').select('id,user_id,amount,status').eq('id',id).limit(1);
  const t=rows?.[0];
  if(!t)return fail('ไม่พบรายการ');
  if(t.status!=='pending')return fail('รายการนี้ถูกดำเนินการไปแล้ว');
  const now=new Date().toISOString();
  if(b.action==='reject'){
    await db.from('topups').update({status:'rejected',note:String(b.note||'ปฏิเสธโดยแอดมิน').slice(0,200),reviewed_at:now}).eq('id',id).eq('status','pending');
    return json({ok:true});
  }
  if(b.action==='approve'){
    const amt=Number(b.amount??t.amount);
    if(!(amt>0))return fail('ยอดเงินไม่ถูกต้อง');
    const claim=await db.from('topups').update({status:'approved',amount:amt,note:'อนุมัติโดยแอดมิน',reviewed_at:now}).eq('id',id).eq('status','pending').select('id');
    if(!claim.data?.length)return fail('รายการนี้ถูกดำเนินการไปแล้ว');
    const w=await db.rpc('add_wallet',{p_uid:t.user_id,p_delta:amt,p_reason:'เติมเงินเข้ากระเป๋า (แอดมินอนุมัติ)'});
    if(w.data==null){await db.from('topups').update({status:'pending',note:'เติมเงินไม่สำเร็จ ลองใหม่'}).eq('id',id);return fail('เติมเงินเข้ากระเป๋าไม่สำเร็จ',500)}
    return json({ok:true});
  }
  return fail('คำสั่งไม่ถูกต้อง');
}
