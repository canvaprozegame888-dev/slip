import bcrypt from 'bcryptjs';
import {adminOnly} from '@/lib/auth';
import {db} from '@/lib/db';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const {data}=await db.from('users').select('id,username,email,phone,role,credits,wallet,credits_expires_at,is_banned,created_at').order('created_at',{ascending:false}).limit(1000);
  return json({ok:true,users:data||[]});
}
export async function POST(req){
  const me=await adminOnly();if(!me)return fail('ไม่มีสิทธิ์',403);
  const b=await readBody(req),id=b.id,self=id===me.id;
  if(!id)return fail('ไม่พบสมาชิก');
  switch(b.action){
    case 'ban':case 'unban':
      if(self)return fail('ไม่สามารถระงับบัญชีตัวเองได้');
      await db.from('users').update({is_banned:b.action==='ban'}).eq('id',id);break;
    case 'credits':{
      const d=parseInt(b.delta,10);if(!d)return fail('ใส่จำนวนเครดิตที่ต้องการเพิ่ม/ลด');
      const r=await db.rpc('add_credits',{p_uid:id,p_delta:d,p_reason:'แอดมินปรับเครดิต'+(b.note?': '+String(b.note).slice(0,80):'')});
      if(r.data==null)return fail('เครดิตไม่พอให้หัก');break}
    case 'wallet':{
      const d=Number(b.delta);if(!d||!isFinite(d))return fail('ใส่ยอดเงินที่ต้องการเพิ่ม/ลด');
      const r=await db.rpc('add_wallet',{p_uid:id,p_delta:d,p_reason:'แอดมินปรับยอดกระเป๋า'+(b.note?': '+String(b.note).slice(0,80):'')});
      if(r.data==null)return fail('ยอดกระเป๋าไม่พอให้หัก');break}
    case 'expiry':{
      let v=null;if(b.date){const t=new Date(b.date);if(isNaN(t))return fail('วันที่ไม่ถูกต้อง');v=t.toISOString()}
      await db.from('users').update({credits_expires_at:v}).eq('id',id);break}
    case 'role':
      if(self)return fail('ไม่สามารถเปลี่ยนสิทธิ์ตัวเองได้');
      if(!['admin','user'].includes(b.role))return fail('สิทธิ์ไม่ถูกต้อง');
      await db.from('users').update({role:b.role}).eq('id',id);break;
    case 'password':{
      const p=String(b.password||'');if(p.length<8)return fail('รหัสผ่านต้องยาวอย่างน้อย 8 ตัว');
      await db.from('users').update({password_hash:await bcrypt.hash(p,10)}).eq('id',id);break}
    default:return fail('คำสั่งไม่ถูกต้อง');
  }
  return json({ok:true});
}
