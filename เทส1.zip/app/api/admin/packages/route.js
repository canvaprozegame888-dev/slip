import {adminOnly} from '@/lib/auth';
import {db} from '@/lib/db';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const {data}=await db.from('packages').select('*').order('sort');
  return json({ok:true,packages:data||[]});
}
export async function POST(req){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const b=await readBody(req);
  if(b.action==='delete'){
    if(!b.id)return fail('ไม่พบแพ็กเกจ');
    await db.from('packages').delete().eq('id',b.id);return json({ok:true});
  }
  const p=b.package||{};
  const row={name:String(p.name||'').trim().slice(0,80),name_en:String(p.name_en||'').trim().slice(0,80),price:Number(p.price),credits:parseInt(p.credits,10),
    duration_days:Math.max(0,parseInt(p.duration_days,10)||0),sort:parseInt(p.sort,10)||0,active:p.active!==false};
  if(!row.name)return fail('ใส่ชื่อแพ็กเกจ');
  if(!(row.price>0))return fail('ราคาต้องมากกว่า 0');
  if(!(row.credits>0))return fail('จำนวนเครดิตต้องมากกว่า 0');
  const r=p.id?await db.from('packages').update(row).eq('id',p.id):await db.from('packages').insert(row);
  if(r.error)return fail('บันทึกไม่สำเร็จ',500);
  return json({ok:true});
}
