import {adminOnly} from '@/lib/auth';
import {db} from '@/lib/db';
import {getSettings} from '@/lib/settings';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
const KEYS=['pp_id','pp_name','signup_bonus','logo_url','site_name','contact_line','contact_phone','contact_email','contact_facebook'];
export async function GET(){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const s=await getSettings();
  return json({ok:true,settings:Object.fromEntries(KEYS.map(k=>[k,s[k]||'']))});
}
export async function POST(req){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const b=(await readBody(req)).settings||{};
  const v=Object.fromEntries(KEYS.map(k=>[k,String(b[k]??'').trim().slice(0,300)]));
  if(v.pp_id){v.pp_id=v.pp_id.replace(/\D/g,'');if(![10,13].includes(v.pp_id.length))return fail('พร้อมเพย์ต้องเป็นเบอร์โทร 10 หลัก หรือเลขบัตรประชาชน/ผู้เสียภาษี 13 หลัก')}
  if(!/^\d{1,5}$/.test(v.signup_bonus||'0'))return fail('เครดิตแถมตอนสมัครต้องเป็นตัวเลข');
  if(!v.signup_bonus)v.signup_bonus='0';
  if(v.logo_url&&!/^https?:\/\//i.test(v.logo_url))return fail('ลิงก์โลโก้ต้องขึ้นต้นด้วย http:// หรือ https://');
  if(!v.site_name)v.site_name='SlipCheck';
  const {error}=await db.from('settings').upsert(KEYS.map(key=>({key,value:v[key]})));
  if(error)return fail('บันทึกไม่สำเร็จ',500);
  return json({ok:true});
}
