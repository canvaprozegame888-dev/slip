import {adminOnly} from '@/lib/auth';
import {db} from '@/lib/db';
import {getSettings,parseGuide,DEFAULT_GUIDE} from '@/lib/settings';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const s=await getSettings();
  return json({ok:true,steps:parseGuide(s.guide_steps),custom:!!s.guide_steps,defaults:DEFAULT_GUIDE});
}
export async function POST(req){
  if(!await adminOnly())return fail('ไม่มีสิทธิ์',403);
  const b=await readBody(req);
  let value='';
  if(!b.reset){
    const steps=(Array.isArray(b.steps)?b.steps:[]).map(x=>({t:String(x.t||'').trim(),b:String(x.b||'').trim(),t_en:String(x.t_en||'').trim(),b_en:String(x.b_en||'').trim()})).filter(x=>x.t||x.b);
    if(!steps.length)return fail('ต้องมีอย่างน้อย 1 ขั้นตอน');
    value=JSON.stringify(steps);
  }
  const {error}=await db.from('settings').upsert([{key:'guide_steps',value}]);
  if(error)return fail('บันทึกไม่สำเร็จ',500);
  return json({ok:true});
}
