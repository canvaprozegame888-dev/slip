import {getUser} from '@/lib/auth';
import {db} from '@/lib/db';
import {getShop} from '@/lib/shop';
import {json} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  const u=await getUser();if(!u)return json({ok:false},401);
  const shop=await getShop(u.id);
  const {data}=shop?await db.from('slips').select('id,trans_ref,amount,sender,receiver,status,reason,created_at').eq('shop_id',shop.id).order('created_at',{ascending:false}).limit(1000):{data:[]};
  return json({ok:true,slips:data||[]});
}
