import {getSettings,PUBLIC_KEYS,pick} from '@/lib/settings';
import {json} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  try{return json(pick(await getSettings(),PUBLIC_KEYS))}catch{return json({})}
}
