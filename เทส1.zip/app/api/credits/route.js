import {getUser} from '@/lib/auth';
import {db} from '@/lib/db';
import {json,fail,readBody} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  const u=await getUser();if(!u)return json({ok:false},401);
  const [pk,lg]=await Promise.all([
    db.from('packages').select('*').eq('active',true).order('sort'),
    db.from('credit_logs').select('id,delta,reason,created_at').eq('user_id',u.id).order('created_at',{ascending:false}).limit(30)]);
  return json({ok:true,user:u,packages:pk.data||[],logs:lg.data||[]});
}
export async function POST(req){
  const u=await getUser();if(!u)return json({ok:false},401);
  const {package_id}=await readBody(req);
  if(!package_id)return fail('ไม่พบแพ็กเกจ');
  const {data,error}=await db.rpc('buy_package',{p_uid:u.id,p_pkg:package_id});
  if(error||!data)return fail('ซื้อแพ็กเกจไม่สำเร็จ ลองใหม่อีกครั้ง',500);
  return json(data);
}
