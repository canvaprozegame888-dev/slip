import {db} from '@/lib/db';
import {sign,sameSig,processEvents} from '@/lib/webhook';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const ok=()=>new Response('OK',{status:200});
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET(){return ok()}

// URL ต่อร้าน: /api/webhook/line/<shop.id> — ดึงร้านเดียวด้วย id แล้วตรวจลายเซ็นกับ secret ของร้านนั้นเท่านั้น
export async function POST(req,{params}){
  const raw=await req.text();
  const sig=req.headers.get('x-line-signature')||'';
  let body;try{body=JSON.parse(raw)}catch{return new Response('bad request',{status:400})}
  const id=params.shopId;
  let shop=null;
  if(UUID.test(id)){const {data}=await db.from('shops').select('*').eq('id',id).limit(1);shop=data?.[0]||null}
  if(!shop)return new Response('not found',{status:404});
  const valid=!!(shop.channel_secret&&shop.channel_token&&sameSig(sign(shop.channel_secret,raw),sig));
  if(!valid)return (body.events||[]).length?new Response('invalid signature',{status:401}):ok(); // ปุ่ม Verify ของ LINE ส่ง events ว่าง
  processEvents(shop,raw).catch(e=>console.error('webhook error',e));
  return ok();
}