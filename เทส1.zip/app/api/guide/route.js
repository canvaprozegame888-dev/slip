import {getSettings,parseGuide} from '@/lib/settings';
import {json,fail} from '@/lib/http';
export const dynamic='force-dynamic';
export async function GET(){
  try{return json({ok:true,steps:parseGuide((await getSettings()).guide_steps)})}catch{return fail('โหลดไม่สำเร็จ',500)}
}
