'use client';
import Link from 'next/link';
import {useState} from 'react';
import {useRouter} from 'next/navigation';
import {useT,ThemeSwitch,LangSwitch,Brand} from '@/components/Providers';
import DemoNotice from '@/components/DemoNotice';
import {api} from '@/components/ui';

export default function LoginForm({initialMode}){
  const {t,lang}=useT(),L=(a,b)=>lang==='en'?b:a,r=useRouter();
  const [mode,setMode]=useState(initialMode),[f,setF]=useState({username:'',password:'',phone:'',email:''}),[err,setErr]=useState(''),[busy,setBusy]=useState(false);
  const set=k=>e=>setF({...f,[k]:e.target.value});
  const reg=mode==='register';
  const submit=async e=>{
    e.preventDefault();setErr('');setBusy(true);
    const res=await api('/api/auth','POST',{mode,...f}).catch(()=>({ok:false,error:L('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้','Cannot reach the server')}));
    if(res.ok){r.push('/dashboard');r.refresh();return}
    setErr(res.error||L('เกิดข้อผิดพลาด','Something went wrong'));setBusy(false);
  };
  return <div className="auth">
    <div className="auth-top"><Link href="/" className="lnk">{t('back')}</Link><div className="row"><LangSwitch/><ThemeSwitch/></div></div>
    <div className="auth-box">
      <div style={{textAlign:'center',marginBottom:18}}><Brand big/><p className="mut" style={{margin:'8px 0 0'}}>{t('login_sub')}</p></div>
      <DemoNotice/>
      <div className="card">
        <div className="tabs">
          <button type="button" className={!reg?'on':''} onClick={()=>{setMode('login');setErr('')}}>{t('nav_login')}</button>
          <button type="button" className={reg?'on':''} onClick={()=>{setMode('register');setErr('')}}>{t('nav_register')}</button>
        </div>
        <form onSubmit={submit}>
          <div className="field"><label>{t('u')}{reg?'':' / '+t('email')}</label><input value={f.username} onChange={set('username')} autoComplete="username" required/></div>
          {reg&&<><div className="field"><label>{t('email')}</label><input type="email" value={f.email} onChange={set('email')} autoComplete="email" required/></div>
          <div className="field"><label>{t('phone')}</label><input type="tel" inputMode="numeric" value={f.phone} onChange={set('phone')} autoComplete="tel" required/></div></>}
          <div className="field"><label>{reg?t('pw8'):t('pw')}</label><input type="password" value={f.password} onChange={set('password')} autoComplete={reg?'new-password':'current-password'} minLength={reg?8:undefined} required/></div>
          {err&&<div className="alert err">{err}</div>}
          <button className="btn lg" style={{width:'100%'}} disabled={busy}>{busy?'...':reg?t('nav_register'):t('nav_login')}</button>
        </form>
      </div>
    </div>
  </div>;
}
