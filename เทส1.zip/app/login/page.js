import {redirect} from 'next/navigation';
import {getUid} from '@/lib/auth';
import LoginForm from './LoginForm';
export const dynamic='force-dynamic';

export default async function LoginPage({searchParams}){
  if(await getUid())redirect('/dashboard');
  return <LoginForm initialMode={searchParams?.mode==='register'?'register':'login'}/>;
}
