import './globals.css';
import {Providers} from '@/components/Providers';

export const metadata={
  title:'SlipCheck — บอทตรวจสลิปโอนเงินในไลน์ออฟ',
  description:'ตรวจสลิปโอนเงินกับธนาคารจริงในไลน์ออฟ กันสลิปปลอม สลิปซ้ำ และโอนผิดบัญชี'
};
export const viewport={width:'device-width',initialScale:1};

const themeInit="try{var t=localStorage.getItem('theme');if(!t)t=matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';document.documentElement.dataset.theme=t}catch(e){}";

export default function RootLayout({children}){
  return <html lang="th" suppressHydrationWarning>
    <head>
      <link rel="preconnect" href="https://fonts.googleapis.com"/>
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin=""/>
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700&display=swap"/>
      <script dangerouslySetInnerHTML={{__html:themeInit}}/>
    </head>
    <body><Providers>{children}</Providers></body>
  </html>;
}
