'use client';
import {useEffect,useState} from 'react';
import {api} from '@/components/ui';

export default function AdminGuide(){
  const [steps,setSteps]=useState(null),[custom,setCustom]=useState(false),[msg,setMsg]=useState(null),[busy,setBusy]=useState(false);
  const load=()=>fetch('/api/admin/guide').then(r=>r.json()).then(r=>{if(r.ok){setSteps(r.steps.map(s=>({t:s.t||'',b:s.b||'',t_en:s.t_en||'',b_en:s.b_en||''})));setCustom(r.custom)}});
  useEffect(()=>{load()},[]);
  if(!steps)return <p className="mut">...</p>;
  const edit=(i,k)=>e=>setSteps(steps.map((s,j)=>j===i?{...s,[k]:e.target.value}:s));
  const move=(i,d)=>{const a=[...steps],j=i+d;if(j<0||j>=a.length)return;[a[i],a[j]]=[a[j],a[i]];setSteps(a)};
  const save=async()=>{
    setBusy(true);setMsg(null);
    const r=await api('/api/admin/guide','POST',{steps}).catch(()=>({ok:false,error:'เชื่อมต่อไม่ได้'}));
    setBusy(false);setMsg(r.ok?{k:'ok',x:'บันทึกแล้ว'}:{k:'err',x:r.error||'บันทึกไม่สำเร็จ'});if(r.ok)setCustom(true);
  };
  const reset=async()=>{
    if(!confirm('คืนค่าเริ่มต้นของคู่มือ? ข้อความที่แก้ไว้จะหายทั้งหมด'))return;
    setBusy(true);const r=await api('/api/admin/guide','POST',{reset:true});setBusy(false);
    if(r.ok){await load();setMsg({k:'ok',x:'คืนค่าเริ่มต้นแล้ว'})}else setMsg({k:'err',x:r.error||'ไม่สำเร็จ'});
  };
  return <>
    <h1>คู่มือเชื่อมต่อ</h1>
    <p className="mut">แก้ขั้นตอนสอนตั้งค่า LINE ที่สมาชิกเห็นในเมนู "คู่มือเชื่อมต่อ LINE" {custom?'(กำลังใช้ข้อความที่แก้ไขเอง)':'(กำลังใช้ค่าเริ่มต้น)'}</p>
    {steps.map((s,i)=><div className="card" key={i}>
      <div className="chead"><h3>ขั้นที่ {i+1}</h3><div className="row" style={{gap:6}}>
        <button className="btn sm sec" disabled={i===0} onClick={()=>move(i,-1)}>↑</button><button className="btn sm sec" disabled={i===steps.length-1} onClick={()=>move(i,1)}>↓</button>
        <button className="btn sm danger" onClick={()=>setSteps(steps.filter((_,j)=>j!==i))}>ลบ</button></div></div>
      <div className="edgrid">
        <div className="field"><label>หัวข้อ (ไทย)</label><input value={s.t} onChange={edit(i,'t')}/></div>
        <div className="field"><label>Title (EN)</label><input value={s.t_en} onChange={edit(i,'t_en')}/></div>
        <div className="field"><label>รายละเอียด (ไทย)</label><textarea value={s.b} onChange={edit(i,'b')}/></div>
        <div className="field"><label>Details (EN)</label><textarea value={s.b_en} onChange={edit(i,'b_en')}/></div>
      </div></div>)}
    {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
    <div className="row"><button className="btn sec" onClick={()=>setSteps([...steps,{t:'',b:'',t_en:'',b_en:''}])}>+ เพิ่มขั้นตอน</button><button className="btn" disabled={busy} onClick={save}>บันทึก</button><button className="btn sec" disabled={busy} onClick={reset}>คืนค่าเริ่มต้น</button></div>
  </>;
}
