'use client';
import {useEffect,useState} from 'react';
import {api,Pill,Empty,dt,n} from '@/components/ui';
import Modal from '@/components/Modal';

const TABS=[['pending','รอตรวจสอบ'],['approved','อนุมัติแล้ว'],['rejected','ปฏิเสธ'],['all','ทั้งหมด']];

export default function AdminTopups(){
  const [st,setSt]=useState('pending'),[rows,setRows]=useState(null),[m,setM]=useState(null),[img,setImg]=useState(undefined),[amt,setAmt]=useState(''),[note,setNote]=useState(''),[msg,setMsg]=useState(null),[busy,setBusy]=useState(false);
  const load=()=>fetch('/api/admin/topups?status='+st).then(r=>r.ok?r.json():null).then(x=>setRows(x?x.topups:[]));
  useEffect(()=>{setRows(null);load()},[st]);
  const open=t=>{setM(t);setAmt(String(t.amount||''));setNote('');setImg(undefined);setMsg(null);
    fetch('/api/admin/topups?img='+t.id).then(r=>r.json()).then(x=>setImg(x.img||null)).catch(()=>setImg(null))};
  const act=async action=>{
    setBusy(true);
    const r=await api('/api/admin/topups','POST',{id:m.id,action,amount:amt,note}).catch(()=>({ok:false,error:'เชื่อมต่อไม่ได้'}));
    setBusy(false);
    if(r.ok){setM(null);setMsg({k:'ok',x:action==='approve'?'อนุมัติและเติมเงินเข้ากระเป๋าแล้ว':'ปฏิเสธรายการแล้ว'});load()}
    else setMsg({k:'err',x:r.error||'ไม่สำเร็จ'});
  };
  return <>
    <h1>รายการเติมเงิน</h1>
    {msg&&!m&&<div className={'alert '+msg.k}>{msg.x}</div>}
    <div className="card">
      <div className="tabs" style={{maxWidth:520}}>{TABS.map(([k,l])=><button key={k} className={st===k?'on':''} onClick={()=>setSt(k)}>{l}</button>)}</div>
      {!rows?<p className="mut">...</p>:rows.length?<div className="tw"><table><thead><tr><th>เวลา</th><th>สมาชิก</th><th className="num">ยอด</th><th>สถานะ</th><th>หมายเหตุ</th><th></th></tr></thead><tbody>
        {rows.map(t=><tr key={t.id}><td style={{whiteSpace:'nowrap'}}>{dt(t.created_at)}</td>
          <td>{t.users?.username||'-'}<div className="mut sm">{t.users?.phone}</div></td>
          <td className="num">฿{n(t.amount)}</td><td><Pill s={t.status}/></td><td className="sm mut">{t.note}{t.trans_ref&&<div style={{wordBreak:'break-all'}}>{t.trans_ref}</div>}</td>
          <td><button className="btn sm sec" onClick={()=>open(t)}>{t.status==='pending'?'ตรวจสอบ':'ดูสลิป'}</button></td></tr>)}
      </tbody></table></div>:<Empty t="ไม่มีรายการ"/>}
    </div>
    {m&&<Modal wide title={`รายการ #${m.id} · ${m.users?.username||''}`} onClose={()=>setM(null)}>
      {img===undefined?<p className="mut">กำลังโหลดรูปสลิป...</p>:img?<img className="slipimg" src={img} alt="slip"/>:<p className="mut">ไม่มีรูปสลิป (รายการนี้ตรวจอัตโนมัติ)</p>}
      {m.status==='pending'?<>
        <div className="field" style={{marginTop:14}}><label>ยอดที่จะเติมเข้ากระเป๋า (บาท) — แก้ไขได้ตามยอดบนสลิปจริง</label><input type="number" min="1" step="0.01" value={amt} onChange={e=>setAmt(e.target.value)}/></div>
        <div className="field"><label>เหตุผล (กรณีปฏิเสธ)</label><input value={note} onChange={e=>setNote(e.target.value)} maxLength={200}/></div>
        {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
        <div className="row"><button className="btn" disabled={busy||!(Number(amt)>0)} onClick={()=>act('approve')}>อนุมัติ + เติมเงิน</button><button className="btn danger" disabled={busy} onClick={()=>act('reject')}>ปฏิเสธ</button></div>
      </>:<p className="mut sm" style={{marginTop:12}}>{m.note}</p>}
    </Modal>}
  </>;
}
