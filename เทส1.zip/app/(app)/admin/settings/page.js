'use client';
import {useEffect,useState} from 'react';
import {api} from '@/components/ui';

export default function AdminSettings(){
  const [f,setF]=useState(null),[msg,setMsg]=useState(null),[busy,setBusy]=useState(false);
  useEffect(()=>{fetch('/api/admin/settings').then(r=>r.json()).then(r=>r.ok&&setF(r.settings))},[]);
  if(!f)return <p className="mut">...</p>;
  const set=k=>e=>setF({...f,[k]:e.target.value});
  const save=async e=>{
    e.preventDefault();setBusy(true);setMsg(null);
    const r=await api('/api/admin/settings','POST',{settings:f}).catch(()=>({ok:false,error:'เชื่อมต่อไม่ได้'}));
    setBusy(false);setMsg(r.ok?{k:'ok',x:'บันทึกแล้ว'}:{k:'err',x:r.error||'บันทึกไม่สำเร็จ'});
  };
  return <>
    <h1>ตั้งค่าระบบ</h1>
    <form onSubmit={save}>
      <div className="card"><h3>บัญชีรับเงิน (พร้อมเพย์)</h3>
        <p className="mut sm">ใช้สร้าง QR ตอนสมาชิกเติมเงิน และตรวจชื่อผู้รับบนสลิปเติมเงิน</p>
        <div className="edgrid">
          <div className="field"><label>เบอร์พร้อมเพย์ (10 หลัก) หรือเลขบัตร/ผู้เสียภาษี (13 หลัก)</label><input value={f.pp_id} onChange={set('pp_id')} inputMode="numeric"/></div>
          <div className="field"><label>ชื่อบัญชีผู้รับ (ตามที่แสดงบนสลิป · เว้นว่าง = ไม่เช็กชื่อ)</label><input value={f.pp_name} onChange={set('pp_name')}/></div>
        </div></div>
      <div className="card"><h3>เว็บไซต์</h3>
        <div className="edgrid">
          <div className="field"><label>ชื่อเว็บ</label><input value={f.site_name} onChange={set('site_name')}/></div>
          <div className="field"><label>ลิงก์โลโก้ (https://...)</label><input value={f.logo_url} onChange={set('logo_url')} placeholder="เว้นว่าง = ใช้ชื่อเว็บแทน"/></div>
          <div className="field"><label>เครดิตทดลองฟรีตอนสมัคร</label><input type="number" min="0" value={f.signup_bonus} onChange={set('signup_bonus')}/></div>
        </div></div>
      <div className="card"><h3>ช่องทางติดต่อ (แสดงหน้าแรก)</h3>
        <div className="edgrid">
          <div className="field"><label>LINE (ลิงก์ หรือ @id)</label><input value={f.contact_line} onChange={set('contact_line')}/></div>
          <div className="field"><label>เบอร์โทร</label><input value={f.contact_phone} onChange={set('contact_phone')}/></div>
          <div className="field"><label>อีเมล</label><input value={f.contact_email} onChange={set('contact_email')}/></div>
          <div className="field"><label>Facebook (ลิงก์)</label><input value={f.contact_facebook} onChange={set('contact_facebook')}/></div>
        </div></div>
      {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
      <button className="btn" disabled={busy}>{busy?'...':'บันทึก'}</button>
    </form>
  </>;
}
