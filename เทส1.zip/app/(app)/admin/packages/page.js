'use client';
import {useState} from 'react';
import {useApi,api,Empty,n} from '@/components/ui';
import Modal from '@/components/Modal';

const BLANK={name:'',name_en:'',price:'',credits:'',duration_days:30,sort:0,active:true};

export default function AdminPackages(){
  const [d,load]=useApi('/api/admin/packages');
  const [p,setP]=useState(null),[msg,setMsg]=useState(null),[busy,setBusy]=useState(false);
  if(!d)return <p className="mut">...</p>;
  const set=k=>e=>setP({...p,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value});
  const save=async e=>{
    e.preventDefault();setBusy(true);
    const r=await api('/api/admin/packages','POST',{package:p}).catch(()=>({ok:false,error:'เชื่อมต่อไม่ได้'}));
    setBusy(false);
    if(r.ok){setP(null);setMsg({k:'ok',x:'บันทึกแล้ว'});load()}else setMsg({k:'err',x:r.error||'ไม่สำเร็จ'});
  };
  const del=async x=>{
    if(!confirm(`ลบแพ็กเกจ "${x.name}"? (ถ้าเคยมีคนซื้อแล้ว แนะนำให้ปิดการขายแทน)`))return;
    const r=await api('/api/admin/packages','POST',{action:'delete',id:x.id});
    setMsg(r.ok?{k:'ok',x:'ลบแล้ว'}:{k:'err',x:r.error||'ลบไม่สำเร็จ'});load();
  };
  return <>
    <div className="row" style={{justifyContent:'space-between'}}><h1>แพ็กเกจ</h1><button className="btn" onClick={()=>{setMsg(null);setP({...BLANK,sort:(d.packages.length+1)})}}>+ เพิ่มแพ็กเกจ</button></div>
    {msg&&!p&&<div className={'alert '+msg.k}>{msg.x}</div>}
    <div className="card">
      {d.packages.length?<div className="tw"><table><thead><tr><th>ลำดับ</th><th>ชื่อ</th><th className="num">ราคา</th><th className="num">เครดิต</th><th className="num">อายุ (วัน)</th><th>สถานะ</th><th></th></tr></thead><tbody>
        {d.packages.map(x=><tr key={x.id}><td>{x.sort}</td><td><b>{x.name}</b><div className="mut sm">{x.name_en}</div></td><td className="num">฿{n(x.price)}</td><td className="num">{n(x.credits)}</td>
          <td className="num">{x.duration_days>0?x.duration_days:'ไม่หมดอายุ'}</td><td>{x.active?<span className="pill ok">เปิดขาย</span>:<span className="pill wait">ปิด</span>}</td>
          <td><div className="row" style={{gap:6}}><button className="btn sm sec" onClick={()=>{setMsg(null);setP({...x,name_en:x.name_en||''})}}>แก้ไข</button><button className="btn sm danger" onClick={()=>del(x)}>ลบ</button></div></td></tr>)}
      </tbody></table></div>:<Empty t="ยังไม่มีแพ็กเกจ"/>}
    </div>
    {p&&<Modal title={p.id?'แก้ไขแพ็กเกจ':'เพิ่มแพ็กเกจ'} onClose={()=>setP(null)}>
      <form onSubmit={save}>
        <div className="edgrid">
          <div className="field"><label>ชื่อ (ไทย)</label><input value={p.name} onChange={set('name')} required/></div>
          <div className="field"><label>ชื่อ (EN)</label><input value={p.name_en} onChange={set('name_en')}/></div>
          <div className="field"><label>ราคา (บาท)</label><input type="number" min="1" step="0.01" value={p.price} onChange={set('price')} required/></div>
          <div className="field"><label>จำนวนเครดิต</label><input type="number" min="1" value={p.credits} onChange={set('credits')} required/></div>
          <div className="field"><label>อายุ (วัน) · 0 = ไม่หมดอายุ</label><input type="number" min="0" value={p.duration_days} onChange={set('duration_days')}/></div>
          <div className="field"><label>ลำดับแสดงผล</label><input type="number" value={p.sort} onChange={set('sort')}/></div>
        </div>
        <label className="chk" style={{marginBottom:14}}><input type="checkbox" checked={p.active} onChange={set('active')}/><span>เปิดขาย</span></label>
        {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
        <div className="row"><button className="btn" disabled={busy}>{busy?'...':'บันทึก'}</button><button type="button" className="btn sec" onClick={()=>setP(null)}>ยกเลิก</button></div>
      </form>
    </Modal>}
  </>;
}
