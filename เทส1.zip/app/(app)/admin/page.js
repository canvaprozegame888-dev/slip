'use client';
import Link from 'next/link';
import {useApi,Stat,Chart,n} from '@/components/ui';

export default function AdminHome(){
  const [d]=useApi('/api/admin/stats');
  if(!d)return <p className="mut">...</p>;
  const t=d.totals||{};
  return <>
    <h1>ภาพรวมระบบ</h1>
    <div className="grid4">
      <Stat t="สมาชิกทั้งหมด" v={n(t.users)}/>
      <Stat t="เครดิตคงเหลือรวม" v={n(t.credits)}/>
      <Stat t="รอตรวจสอบเติมเงิน" v={n(t.pending)} tone={t.pending>0?'fail':''} sub={<Link href="/admin/topups" style={{textDecoration:'underline'}}>ไปที่รายการเติมเงิน</Link>}/>
      <Stat t="รายได้รวม" v={'฿'+n(t.revenue)} sub={'วันนี้ ฿'+n(t.revenue_today)}/>
    </div>
    <Chart data={d.daily} title="สลิปที่ตรวจทั้งระบบ 14 วันล่าสุด" sub="ทุกร้านรวมกัน"/>
  </>;
}
