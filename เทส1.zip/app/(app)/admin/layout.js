import {redirect} from 'next/navigation';
import {adminOnly} from '@/lib/auth';
export const dynamic='force-dynamic';

export default async function AdminLayout({children}){
  if(!await adminOnly())redirect('/dashboard');
  return children;
}
