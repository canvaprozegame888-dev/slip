'use client';
import {useState} from 'react';
import {useApi,api,Empty,dt,n,day} from '@/components/ui';
import Modal from '@/components/Modal';

const TITLES={credits:'ปรับเครดิต',wallet:'ปรับยอดกระเป๋าเงิน',expiry:'ตั้งวันหมดอายุเครดิต',password:'ตั้งรหัสผ่านใหม่'};

export default function AdminUsers(){
  const [d,load]=useApi('/api/admin/users');
  const [q,setQ]=useState(''),[m,setM]=useState(null),[v,setV]=useState(''),[note,setNote]=useState(''),[msg,setMsg]=useState(null),[busy,setBusy]=useState(false);
  if(!d)return <p className="mut">...</p>;
  const k=q.trim().toLowerCase();
  const rows=d.users.filter(u=>!k||[u.username,u.email,u.phone].some(x=>String(x||'').toLowerCase().includes(k)));
  const run=async(id,body)=>{
    setBusy(true);
    const r=await api('/api/admin/users','POST',{id,...body}).catch(()=>({ok:false,error:'เชื่อมต่อไม่ได้'}));
    setBusy(false);
    if(r.ok){setM(null);setMsg({k:'ok',x:'ทำรายการสำเร็จ'});load()}else setMsg({k:'err',x:r.error||'ไม่สำเร็จ'});
    return r.ok;
  };
  const open=(u,type)=>{setM({u,type});setV(type==='expiry'&&u.credits_expires_at?u.credits_expires_at.slice(0,10):'');setNote('');setMsg(null)};
  const submit=e=>{
    e.preventDefault();
    const {u,type}=m;
    if(type==='credits'||type==='wallet')run(u.id,{action:type,delta:v,note});
    else if(type==='expiry')run(u.id,{action:'expiry',date:v});
    else if(type==='password')run(u.id,{action:'password',password:v});
  };
  return <>
    <h1>สมาชิก</h1>
    {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
    <div className="card">
      <div className="bar"><input placeholder="ค้นหา ยูสเซอร์ / อีเมล / เบอร์" value={q} onChange={e=>setQ(e.target.value)}/><span className="mut sm">{n(rows.length)} คน</span></div>
      {rows.length?<div className="tw"><table><thead><tr><th>สมาชิก</th><th>ติดต่อ</th><th className="num">เครดิต</th><th className="num">กระเป๋า</th><th>สถานะ</th><th></th></tr></thead><tbody>
        {rows.map(u=><tr key={u.id}>
          <td><b>{u.username}</b>{u.role==='admin'&&<span className="pill ok" style={{marginLeft:6}}>admin</span>}<div className="mut sm">สมัคร {day(u.created_at)}</div></td>
          <td className="sm">{u.email}<div className="mut">{u.phone}</div></td>
          <td className="num">{n(u.credits)}<div className="mut sm">{u.credits_expires_at?'หมด '+day(u.credits_expires_at):'ไม่หมดอายุ'}</div></td>
          <td className="num">฿{n(u.wallet)}</td>
          <td>{u.is_banned?<span className="pill fail">ระงับ</span>:<span className="pill ok">ปกติ</span>}</td>
          <td><div className="row" style={{gap:6}}>
            <button className="btn sm sec" onClick={()=>open(u,'credits')}>เครดิต</button>
            <button className="btn sm sec" onClick={()=>open(u,'wallet')}>กระเป๋า</button>
            <button className="btn sm sec" onClick={()=>open(u,'expiry')}>วันหมดอายุ</button>
            <button className="btn sm sec" onClick={()=>open(u,'password')}>รหัสผ่าน</button>
            <button className="btn sm sec" onClick={()=>confirm(`เปลี่ยนสิทธิ์ ${u.username} เป็น ${u.role==='admin'?'สมาชิกทั่วไป':'แอดมิน'}?`)&&run(u.id,{action:'role',role:u.role==='admin'?'user':'admin'})}>{u.role==='admin'?'ถอดแอดมิน':'ตั้งเป็นแอดมิน'}</button>
            <button className={'btn sm '+(u.is_banned?'sec':'danger')} onClick={()=>confirm(`${u.is_banned?'ปลดระงับ':'ระงับ'} ${u.username}?`)&&run(u.id,{action:u.is_banned?'unban':'ban'})}>{u.is_banned?'ปลดระงับ':'ระงับ'}</button>
          </div></td>
        </tr>)}
      </tbody></table></div>:<Empty t="ไม่พบสมาชิก"/>}
    </div>
    {m&&<Modal title={`${TITLES[m.type]} · ${m.u.username}`} onClose={()=>setM(null)}>
      <form onSubmit={submit}>
        {(m.type==='credits'||m.type==='wallet')&&<>
          <p className="mut sm">ปัจจุบัน: {m.type==='credits'?n(m.u.credits)+' เครดิต':'฿'+n(m.u.wallet)} · ใส่ค่าติดลบเพื่อหัก</p>
          <div className="field"><label>{m.type==='credits'?'จำนวนเครดิต (+/−)':'ยอดเงิน (+/−)'}</label><input type="number" step={m.type==='credits'?'1':'0.01'} value={v} onChange={e=>setV(e.target.value)} required autoFocus/></div>
          <div className="field"><label>หมายเหตุ (ไม่บังคับ)</label><input value={note} onChange={e=>setNote(e.target.value)} maxLength={80}/></div></>}
        {m.type==='expiry'&&<div className="field"><label>วันหมดอายุ (เว้นว่าง = ไม่หมดอายุ)</label><input type="date" value={v} onChange={e=>setV(e.target.value)}/></div>}
        {m.type==='password'&&<div className="field"><label>รหัสผ่านใหม่ (8 ตัวขึ้นไป)</label><input type="text" value={v} onChange={e=>setV(e.target.value)} minLength={8} required autoFocus/></div>}
        <div className="row"><button className="btn" disabled={busy}>{busy?'...':'บันทึก'}</button><button type="button" className="btn sec" onClick={()=>setM(null)}>ยกเลิก</button></div>
      </form>
    </Modal>}
  </>;
}
