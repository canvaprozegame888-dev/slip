'use client';
import Link from 'next/link';
import {useApi} from '@/components/ui';
import {useT} from '@/components/Providers';

export default function Guide(){
  const {t,lang}=useT();
  const [d]=useApi('/api/guide');
  if(!d)return <p className="mut">...</p>;
  return <>
    <h1>{t('guide_h')}</h1>
    <p className="mut">{t('guide_p')}</p>
    <div className="card"><ol className="steps">{d.steps.map((s,i)=><li key={i}><div><b>{lang==='en'&&s.t_en?s.t_en:s.t}</b><p style={{whiteSpace:'pre-line'}}>{lang==='en'&&s.b_en?s.b_en:s.b}</p></div></li>)}</ol></div>
    <Link className="btn" href="/settings">{t('guide_go')}</Link>
  </>;
}
