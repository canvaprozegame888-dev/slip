'use client';
import Link from 'next/link';
import {useApi,Stat,Pill,Chart,Empty,dt,n,day} from '@/components/ui';
import {useT} from '@/components/Providers';

export default function Dashboard(){
  const {t,lang}=useT(),L=(a,b)=>lang==='en'?b:a;
  const [d]=useApi('/api/dashboard');
  if(!d)return <p className="mut">...</p>;
  const u=d.user,tot=d.month.ok+d.month.fail;
  const exp=u.expired?t('expired'):u.credits_expires_at?t('expires')+' '+day(u.credits_expires_at):t('noexp');
  return <>
    <h1>{t('m_dash')}</h1>
    {!d.connected&&<div className="alert info">
      <b>{L('ยังไม่ได้เชื่อมต่อ LINE Official Account','LINE Official Account is not connected yet')}</b>
      <div className="row" style={{marginTop:8}}><Link className="btn sm" href="/guide">{t('m_guide')}</Link><Link className="btn sm sec" href="/settings">{t('m_set')}</Link></div>
    </div>}
    {u.credits<=0&&<div className="alert err">{u.expired?L('แพ็กเกจหมดอายุแล้ว บอทจะไม่ตรวจสลิปจนกว่าจะซื้อแพ็กเกจใหม่','Your package has expired. The bot will not verify slips until you buy a new one.'):L('เครดิตหมด บอทจะไม่ตรวจสลิปจนกว่าจะซื้อแพ็กเกจเพิ่ม','You are out of credits. The bot will not verify slips until you buy a package.')} <Link href="/credits" style={{textDecoration:'underline'}}>{t('m_pkg')}</Link></div>}
    <div className="grid4">
      <Stat t={t('credit')} v={n(u.credits)} sub={exp} tone={u.credits>0?'ok':'fail'}/>
      <Stat t={t('wallet')} v={'฿'+n(u.wallet)} sub={<Link href="/wallet" style={{textDecoration:'underline'}}>{t('m_wallet')}</Link>}/>
      <Stat t={L('วันนี้ (สำเร็จ / ไม่สำเร็จ)','Today (ok / failed)')} v={d.today.ok+' / '+d.today.fail} u={L('สลิป','slips')}/>
      <Stat t={L('30 วันที่ผ่านมา','Last 30 days')} v={tot?Math.round(d.month.ok/tot*100)+'%':'-'} sub={L('อัตราสลิปผ่าน · ทั้งหมด ','Pass rate · total ')+n(tot)}/>
    </div>
    <Chart data={d.daily} title={L('สลิปที่ตรวจ 14 วันล่าสุด','Slips checked, last 14 days')} sub={L('แยกตามสำเร็จ / ไม่สำเร็จ','Split by success / failed')}/>
    <div className="card">
      <div className="chead"><h3>{L('รายการล่าสุด','Recent slips')}</h3><Link className="btn sm sec" href="/history">{t('m_hist')}</Link></div>
      {d.recent.length?<div className="tw"><table><thead><tr><th>{t('time')}</th><th className="num">{t('amount')}</th><th>{L('ผู้โอน','Sender')}</th><th>{t('status')}</th></tr></thead><tbody>
        {d.recent.map(s=><tr key={s.id}><td>{dt(s.created_at)}</td><td className="num">{s.amount!=null?'฿'+n(s.amount):'-'}</td><td>{s.sender||'-'}</td><td><Pill s={s.status}/>{s.reason&&<div className="mut sm">{s.reason}</div>}</td></tr>)}
      </tbody></table></div>:<Empty t={t('none')}/>}
    </div>
  </>;
}
