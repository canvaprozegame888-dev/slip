'use client';
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {Pill,Empty,dt,n} from '@/components/ui';
import {useT} from '@/components/Providers';

async function shrink(f){
  if(f.size<1.5e6)return f;
  try{
    const b=await createImageBitmap(f),s=Math.min(1,2000/Math.max(b.width,b.height));
    const c=document.createElement('canvas');c.width=Math.round(b.width*s);c.height=Math.round(b.height*s);
    c.getContext('2d').drawImage(b,0,0,c.width,c.height);
    const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.88));
    return blob?new File([blob],'slip.jpg',{type:'image/jpeg'}):f;
  }catch{return f}
}

export default function Wallet(){
  const {t,lang}=useT(),L=(a,b)=>lang==='en'?b:a;
  const [d,setD]=useState(null),[amount,setAmount]=useState(''),[file,setFile]=useState(null),[busy,setBusy]=useState(false),[msg,setMsg]=useState(null),[canManual,setCanManual]=useState(false),[back,setBack]=useState(false),[key,setKey]=useState(0);
  const load=a=>fetch('/api/wallet'+(a>=1?'?amount='+a:'')).then(r=>r.ok?r.json():null).then(x=>x&&setD(x)).catch(()=>{});
  useEffect(()=>{
    const need=Number(new URLSearchParams(location.search).get('need'));
    if(need>0){setAmount(String(Math.ceil(need)));setBack(true)}
  },[]);
  useEffect(()=>{const a=Number(amount);const id=setTimeout(()=>load(a),a>=1?350:0);return()=>clearTimeout(id)},[amount]);
  const send=async mode=>{
    if(!file)return setMsg({k:'err',x:t('w_pick')});
    if(mode==='manual'&&!(Number(amount)>=1))return setMsg({k:'err',x:L('กรุณาใส่ยอดที่เติม','Please enter the amount')});
    setBusy(true);setMsg(null);
    const fd=new FormData();fd.append('file',await shrink(file));fd.append('amount',amount||'0');fd.append('mode',mode);
    const r=await fetch('/api/wallet',{method:'POST',body:fd}).then(x=>x.json()).catch(()=>({ok:false,error:L('เชื่อมต่อเซิร์ฟเวอร์ไม่ได้','Cannot reach the server')}));
    setBusy(false);
    if(r.ok){
      setMsg({k:'ok',x:r.pending?t('w_pending'):t('w_ok')+' ฿'+n(r.wallet)});setFile(null);setKey(key+1);setCanManual(false);
      load(Number(amount));dispatchEvent(new Event('credits'));
    }else{setMsg({k:'err',x:r.error||L('เกิดข้อผิดพลาด','Something went wrong')});if(mode==='auto')setCanManual(true)}
  };
  if(!d)return <p className="mut">...</p>;
  return <>
    <h1>{t('w_title')}</h1>
    <div className="grid2">
      <div className="card">
        <div className="field"><label>{t('w_amount')}</label><input type="number" min="1" max="1000000" inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0"/></div>
        <div className="row" style={{marginBottom:14}}><span className="mut sm">{t('w_quick')}</span>{[100,300,500,1000].map(v=><button key={v} type="button" className="btn sm sec" onClick={()=>setAmount(String(v))}>฿{n(v)}</button>)}</div>
        {!d.pp.ok?<div className="alert err">{t('w_nopp')}</div>:d.qr?<div className="qrbox"><img src={d.qr} alt="PromptPay QR"/>{d.pp.name&&<div className="mut sm" style={{marginTop:6}}>{d.pp.name}</div>}<div style={{fontWeight:700,fontSize:20}}>฿{n(amount)}</div></div>:<p className="mut sm">{L('ใส่ยอดเพื่อสร้าง QR พร้อมเพย์','Enter an amount to generate the PromptPay QR')}</p>}
      </div>
      <div className="card">
        <p className="mut sm">{t('w_scan')}</p>
        <div className="field"><label>{L('รูปสลิป','Slip image')}</label><input key={key} type="file" accept="image/*" onChange={e=>{setFile(e.target.files?.[0]||null);setMsg(null)}}/></div>
        <div className="row"><button className="btn" disabled={busy||!file} onClick={()=>send('auto')}>{busy?t('w_checking'):t('w_check')}</button>
          {canManual&&<button className="btn sec" disabled={busy||!file} onClick={()=>send('manual')}>{t('w_manual')}</button>}</div>
        {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
        {back&&msg?.k==='ok'&&<Link className="btn sm" href="/credits">{t('w_back')}</Link>}
        <div className="alert info sm">{L('ยอดที่เติมเข้ากระเป๋าคือยอดโอนจริงตามสลิป','The credited amount is the actual amount on the slip.')}</div>
      </div>
    </div>
    <div className="grid2">
      <div className="card"><h3>{t('w_hist')}</h3>
        {d.topups.length?<div className="tw"><table><thead><tr><th>{t('time')}</th><th className="num">{t('amount')}</th><th>{t('status')}</th></tr></thead><tbody>
          {d.topups.map(x=><tr key={x.id}><td>{dt(x.created_at)}</td><td className="num">฿{n(x.amount)}</td><td><Pill s={x.status}/></td></tr>)}</tbody></table></div>:<Empty t={t('none')}/>}
      </div>
      <div className="card"><h3>{t('w_moves')}</h3>
        {d.moves.length?<div className="tw"><table><thead><tr><th>{t('time')}</th><th>{t('item')}</th><th className="num">{t('amount')}</th></tr></thead><tbody>
          {d.moves.map(x=><tr key={x.id}><td>{dt(x.created_at)}</td><td>{x.reason}</td><td className="num" style={{color:x.delta>=0?'var(--ok)':'var(--fail)'}}>{x.delta>=0?'+':''}{n(x.delta)}</td></tr>)}</tbody></table></div>:<Empty t={t('none')}/>}
      </div>
    </div>
  </>;
}
