'use client';
import {useState} from 'react';
import {useApi,Pill,Empty,dt,n} from '@/components/ui';
import {useT} from '@/components/Providers';
const PER=20;

export default function History(){
  const {t,lang}=useT(),L=(a,b)=>lang==='en'?b:a;
  const [d]=useApi('/api/history');
  const [q,setQ]=useState(''),[st,setSt]=useState('all'),[pg,setPg]=useState(1);
  if(!d)return <p className="mut">...</p>;
  const k=q.trim().toLowerCase();
  const rows=d.slips.filter(s=>(st==='all'||(st==='ok')===(s.status==='ok'))&&(!k||[s.trans_ref,s.sender,s.receiver,s.reason,String(s.amount??'')].some(x=>String(x||'').toLowerCase().includes(k))));
  const pages=Math.max(1,Math.ceil(rows.length/PER)),p=Math.min(pg,pages),view=rows.slice((p-1)*PER,p*PER);
  return <>
    <h1>{t('m_hist')}</h1>
    <div className="card">
      <div className="bar">
        <input placeholder={L('ค้นหา ชื่อ / เลขอ้างอิง / ยอด','Search name / reference / amount')} value={q} onChange={e=>{setQ(e.target.value);setPg(1)}}/>
        <select value={st} onChange={e=>{setSt(e.target.value);setPg(1)}}>
          <option value="all">{L('ทุกสถานะ','All statuses')}</option><option value="ok">{L('สำเร็จ','Success')}</option><option value="fail">{L('ไม่สำเร็จ','Failed')}</option>
        </select>
        <span className="mut sm">{n(rows.length)} {L('รายการ','items')}</span>
      </div>
      {view.length?<div className="tw"><table><thead><tr><th>{t('time')}</th><th className="num">{t('amount')}</th><th>{L('ผู้โอน','Sender')}</th><th>{L('ผู้รับ','Receiver')}</th><th>{L('เลขอ้างอิง','Reference')}</th><th>{t('status')}</th></tr></thead><tbody>
        {view.map(s=><tr key={s.id}><td style={{whiteSpace:'nowrap'}}>{dt(s.created_at)}</td><td className="num">{s.amount!=null?'฿'+n(s.amount):'-'}</td><td>{s.sender||'-'}</td><td>{s.receiver||'-'}</td><td className="mut sm" style={{wordBreak:'break-all'}}>{s.trans_ref||'-'}</td><td><Pill s={s.status}/>{s.reason&&<div className="mut sm">{s.reason}</div>}</td></tr>)}
      </tbody></table></div>:<Empty t={t('none')}/>}
      {pages>1&&<div className="pager"><button className="btn sm sec" disabled={p<=1} onClick={()=>setPg(p-1)}>←</button><span className="mut sm">{p} / {pages}</span><button className="btn sm sec" disabled={p>=pages} onClick={()=>setPg(p+1)}>→</button></div>}
    </div>
    {d.slips.length>=1000&&<p className="mut sm">{L('แสดง 1,000 รายการล่าสุด','Showing the latest 1,000 items')}</p>}
  </>;
}
