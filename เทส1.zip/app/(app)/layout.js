import {redirect} from 'next/navigation';
import {getUser} from '@/lib/auth';
import Shell from '@/components/Shell';
export const dynamic='force-dynamic';

export default async function AppLayout({children}){
  if(!await getUser())redirect('/login');
  return <Shell>{children}</Shell>;
}
