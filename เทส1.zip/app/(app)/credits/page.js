'use client';
import Link from 'next/link';
import {useState} from 'react';
import {useApi,api,Empty,dt,n,day} from '@/components/ui';
import Modal from '@/components/Modal';
import {useT} from '@/components/Providers';

export default function Credits(){
  const {t,lang}=useT(),L=(a,b)=>lang==='en'?b:a;
  const [d,load]=useApi('/api/credits');
  const [pick,setPick]=useState(null),[busy,setBusy]=useState(false),[msg,setMsg]=useState(null);
  if(!d)return <p className="mut">...</p>;
  const u=d.user,nm=p=>lang==='en'&&p.name_en?p.name_en:p.name;
  const newExp=p=>{
    if(!(p.duration_days>0))return t('noexp');
    const base=u.credits_expires_at&&!u.expired?new Date(u.credits_expires_at):new Date();
    return day(new Date(base.getTime()+p.duration_days*86400000));
  };
  const buy=async()=>{
    setBusy(true);
    const r=await api('/api/credits','POST',{package_id:pick.id}).catch(()=>({ok:false}));
    setBusy(false);
    if(r.ok){setMsg({k:'ok',x:t('k_done')+' · '+nm(pick)});setPick(null);load();dispatchEvent(new Event('credits'))}
    else{setPick(null);setMsg({k:'err',x:r.error==='insufficient'?t('k_short')+' ฿'+n(r.shortfall):(r.error||L('ซื้อไม่สำเร็จ','Purchase failed'))})}
  };
  const exp=u.expired?t('expired'):u.credits_expires_at?t('expires')+' '+day(u.credits_expires_at):t('noexp');
  return <>
    <h1>{t('k_title')}</h1>
    <div className="grid4">
      <div className="card stat"><div className="mut">{t('credit')}</div><div className={'big '+(u.credits>0?'ok':'fail')}>{n(u.credits)}</div><div className="mut sm">{exp}</div></div>
      <div className="card stat"><div className="mut">{t('wallet')}</div><div className="big">฿{n(u.wallet)}</div><div className="mut sm"><Link href="/wallet" style={{textDecoration:'underline'}}>{t('m_wallet')}</Link></div></div>
    </div>
    {msg&&<div className={'alert '+msg.k}>{msg.x}{msg.k==='err'&&<> · <Link href="/wallet" style={{textDecoration:'underline'}}>{t('k_go')}</Link></>}</div>}
    {d.packages.length?<div className="pk">{d.packages.map(p=><div className="card" key={p.id}>
      <h3>{nm(p)}</h3><div className="price">฿{n(p.price)}</div>
      <ul><li>{n(p.credits)} {t('p_cr')}</li><li>{p.duration_days>0?p.duration_days+' '+t('p_day'):t('p_never')}</li><li>≈ {(p.price/p.credits).toFixed(2)} {t('p_unit')}/{L('สลิป','slip')}</li></ul>
      {u.wallet>=p.price?<button className="btn" onClick={()=>{setMsg(null);setPick(p)}}>{t('k_buy')}</button>
        :<Link className="btn sec" href={'/wallet?need='+Math.ceil(p.price-u.wallet)}>{t('k_short')} ฿{n(p.price-u.wallet)} · {t('k_go')}</Link>}
    </div>)}</div>:<div className="card"><Empty t={t('p_none')}/></div>}
    <div className="card"><h3>{t('k_hist')}</h3>
      {d.logs.length?<div className="tw"><table><thead><tr><th>{t('time')}</th><th>{t('item')}</th><th className="num">{t('credit')}</th></tr></thead><tbody>
        {d.logs.map(x=><tr key={x.id}><td>{dt(x.created_at)}</td><td>{x.reason}</td><td className="num" style={{color:x.delta>=0?'var(--ok)':'var(--fail)'}}>{x.delta>=0?'+':''}{n(x.delta)}</td></tr>)}</tbody></table></div>:<Empty t={t('none')}/>}
    </div>
    {pick&&<Modal title={t('k_confirm')} onClose={()=>!busy&&setPick(null)}>
      <h3>{nm(pick)}</h3>
      <table><tbody>
        <tr><td className="mut">{t('k_will')}</td><td className="num"><b>฿{n(pick.price)}</b></td></tr>
        <tr><td className="mut">{t('k_get')}</td><td className="num"><b>{n(pick.credits)} {t('p_cr')}</b></td></tr>
        <tr><td className="mut">{t('k_ext')}</td><td className="num"><b>{newExp(pick)}</b></td></tr>
      </tbody></table>
      <p className="mut sm" style={{marginTop:10}}>{t('k_stack')}</p>
      <div className="row"><button className="btn" disabled={busy} onClick={buy}>{busy?'...':t('k_yes')}</button><button className="btn sec" disabled={busy} onClick={()=>setPick(null)}>{t('k_no')}</button></div>
    </Modal>}
  </>;
}
