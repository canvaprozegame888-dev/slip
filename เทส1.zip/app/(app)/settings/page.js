'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {api} from '@/components/ui';
import {THEMES} from '@/lib/flex';
import {useT} from '@/components/Providers';

export default function Settings(){
  const {t,lang}=useT(),L=(a,b)=>lang==='en'?b:a;
  const [f,setF]=useState(null),[msg,setMsg]=useState(null),[busy,setBusy]=useState(false),[hook,setHook]=useState(''),[copied,setCopied]=useState(false);
  useEffect(()=>{
    fetch('/api/shop').then(r=>r.json()).then(r=>{if(!r.ok)return;setHook(location.origin+'/api/webhook/line/'+r.shop.id);setF({name:r.shop.name,channel_id:r.shop.channel_id,channel_secret:r.shop.secret,channel_token:r.shop.token,receiver_names:(r.shop.receiver_names||[]).join('\n'),allow_duplicate:r.shop.allow_duplicate,theme_ok:r.shop.theme_ok,theme_fail:r.shop.theme_fail})});
  },[]);
  if(!f)return <p className="mut">...</p>;
  const set=k=>e=>setF({...f,[k]:e.target.type==='checkbox'?e.target.checked:e.target.value});
  const save=async e=>{
    e.preventDefault();setBusy(true);setMsg(null);
    const r=await api('/api/shop','POST',{mode:'save',...f}).catch(()=>({ok:false}));
    setBusy(false);
    if(r.ok){setF({...f,channel_secret:r.shop.secret,channel_token:r.shop.token,receiver_names:r.shop.receiver_names.join('\n')});setMsg({k:'ok',x:L('บันทึกแล้ว','Saved')})}
    else setMsg({k:'err',x:r.error||L('บันทึกไม่สำเร็จ','Could not save')});
  };
  const test=async()=>{
    setBusy(true);setMsg(null);
    const r=await api('/api/shop','POST',{mode:'test',token:f.channel_token}).catch(()=>({ok:false}));
    setBusy(false);
    setMsg(r.ok?{k:'ok',x:L('เชื่อมต่อสำเร็จ: ','Connected: ')+r.name}:{k:'err',x:r.error||L('ทดสอบไม่สำเร็จ','Test failed')});
  };
  const copy=async()=>{try{await navigator.clipboard.writeText(hook);setCopied(true);setTimeout(()=>setCopied(false),1500)}catch{}};
  const Sw=({kind,cur,field})=><div className="swatches">{Object.entries(THEMES[kind]).map(([k,[c,bg]])=>
    <button type="button" key={k} title={k} className={cur===k?'on':''} style={{background:`linear-gradient(135deg,${c} 55%,${bg} 55%)`}} onClick={()=>setF({...f,[field]:k})}>{cur===k?'✓':''}</button>)}</div>;
  return <>
    <h1>{t('m_set')}</h1>
    <form onSubmit={save}>
      <div className="card">
        <h3>{L('เชื่อมต่อ LINE Official Account','Connect LINE Official Account')}</h3>
        <p className="mut sm">{L('ยังไม่เคยตั้งค่า? ทำตาม ','New here? Follow the ')}<Link href="/guide" style={{textDecoration:'underline'}}>{t('m_guide')}</Link></p>
        <div className="grid2">
          <div className="field"><label>{L('ชื่อร้าน','Shop name')}</label><input value={f.name} onChange={set('name')} maxLength={100}/></div>
          <div className="field"><label>Channel ID</label><input value={f.channel_id} onChange={set('channel_id')} inputMode="numeric"/></div>
          <div className="field"><label>Channel secret</label><input value={f.channel_secret} onChange={set('channel_secret')} autoComplete="off" spellCheck="false"/></div>
          <div className="field"><label>Channel access token (long-lived)</label><input value={f.channel_token} onChange={set('channel_token')} autoComplete="off" spellCheck="false"/></div>
        </div>
        <p className="mut sm">{L('ค่าที่บันทึกแล้วจะถูกซ่อนบางส่วน หากไม่ต้องการเปลี่ยนให้ปล่อยไว้เหมือนเดิม','Saved values are partly hidden. Leave them as they are to keep the current ones.')}</p>
        <div className="field"><label>Webhook URL</label><div className="copy"><input readOnly value={hook}/><button type="button" className="btn sec" onClick={copy}>{copied?'✓':L('คัดลอก','Copy')}</button></div></div>
      </div>
      <div className="card">
        <h3>{L('กติกาตรวจสลิป','Verification rules')}</h3>
        <div className="field"><label>{L('ชื่อผู้รับเงินของร้าน (1 ชื่อต่อบรรทัด · เว้นว่าง = ไม่เช็กชื่อ)','Receiver name(s) (one per line · empty = do not check)')}</label><textarea value={f.receiver_names} onChange={set('receiver_names')} placeholder={L('เช่น สมชาย ใจดี','e.g. Somchai Jaidee')}/></div>
        <label className="chk"><input type="checkbox" checked={f.allow_duplicate} onChange={set('allow_duplicate')}/><span>{L('อนุญาตสลิปซ้ำ (ไม่แนะนำ)','Allow duplicate slips (not recommended)')}</span></label>
      </div>
      <div className="card">
        <h3>{L('ธีมข้อความตอบกลับ','Reply message theme')}</h3>
        <div className="grid2">
          <div><label>{L('สลิปถูกต้อง','Valid slip')}</label><Sw kind="ok" cur={f.theme_ok} field="theme_ok"/></div>
          <div><label>{L('สลิปผิดพลาด','Invalid slip')}</label><Sw kind="fail" cur={f.theme_fail} field="theme_fail"/></div>
        </div>
      </div>
      {msg&&<div className={'alert '+msg.k}>{msg.x}</div>}
      <div className="row"><button className="btn" disabled={busy}>{busy?'...':L('บันทึก','Save')}</button><button type="button" className="btn sec" disabled={busy} onClick={test}>{L('ทดสอบการเชื่อมต่อ','Test connection')}</button></div>
    </form>
  </>;
}