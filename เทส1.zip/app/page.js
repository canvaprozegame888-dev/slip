import {db} from '@/lib/db';
import {getUid} from '@/lib/auth';
import {getSettings,PUBLIC_KEYS,pick} from '@/lib/settings';
import Landing from '@/components/Landing';
export const dynamic='force-dynamic';

export default async function Home(){
  let s={},packages=[];
  try{
    s=await getSettings();
    packages=(await db.from('packages').select('*').eq('active',true).order('sort')).data||[];
  }catch{}
  const loggedIn=!!(await getUid());
  return <Landing s={pick(s,PUBLIC_KEYS)} packages={packages} loggedIn={loggedIn}/>;
}
