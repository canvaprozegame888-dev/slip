-- รันครั้งเดียวใน Supabase SQL Editor (รันซ้ำได้ปลอดภัย)
alter table topups add column if not exists qr_hash text;
create unique index if not exists topups_qr_uq on topups(qr_hash) where qr_hash is not null and status in ('pending','approved');
