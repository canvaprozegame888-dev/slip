-- รันได้ทั้งติดตั้งใหม่และอัปเกรดจากเวอร์ชันก่อน
create extension if not exists pgcrypto;
create table if not exists users(id uuid primary key default gen_random_uuid(),phone text unique not null,email text unique not null,username text unique not null,password_hash text not null,created_at timestamptz default now());
alter table users add column if not exists role text default 'user';
alter table users add column if not exists credits int default 0;
alter table users add column if not exists is_banned boolean default false;
create table if not exists shops(id uuid primary key default gen_random_uuid(),user_id uuid unique references users on delete cascade,name text,channel_id text,channel_secret text,channel_token text,receiver_names text[] default '{}',allow_duplicate boolean default false,theme_ok text default 'green',theme_fail text default 'red');
create table if not exists slips(id bigserial primary key,shop_id uuid references shops on delete cascade,trans_ref text,amount numeric,sender text,receiver text,status text,reason text,created_at timestamptz default now());
create index if not exists slips_shop_ref on slips(shop_id,trans_ref);
create index if not exists slips_created on slips(created_at);
create table if not exists packages(id uuid primary key default gen_random_uuid(),name text not null,price numeric not null,credits int not null,active boolean default true,sort int default 0);
create table if not exists topups(id bigserial primary key,user_id uuid references users on delete cascade,package_id uuid references packages on delete set null,package_name text,amount numeric,credits int,trans_ref text unique,status text default 'pending',slip_img text,note text,created_at timestamptz default now(),reviewed_at timestamptz);
create table if not exists credit_logs(id bigserial primary key,user_id uuid references users on delete cascade,delta int,reason text,created_at timestamptz default now());
create table if not exists settings(key text primary key,value text);
insert into settings values('pp_id',''),('pp_name',''),('signup_bonus','10') on conflict do nothing;
insert into packages(name,price,credits,sort) select * from (values('เริ่มต้น',99,100,1),('ธุรกิจ',299,350,2),('โปร',999,1300,3)) as v(a,b,c,d) where not exists(select 1 from packages);
alter table users enable row level security;alter table shops enable row level security;alter table slips enable row level security;alter table packages enable row level security;alter table topups enable row level security;alter table credit_logs enable row level security;alter table settings enable row level security;
create or replace function add_credits(p_uid uuid,p_delta int,p_reason text,p_log boolean default true) returns int language plpgsql as $$
declare c int; begin
  update users set credits=credits+p_delta where id=p_uid and credits+p_delta>=0 returning credits into c;
  if c is not null and p_log then insert into credit_logs(user_id,delta,reason) values(p_uid,p_delta,p_reason); end if;
  return c; end $$;
create or replace function daily_stats(p_shop uuid default null) returns table(d text,ok bigint,fail bigint) language sql as $$
  select to_char(created_at at time zone 'Asia/Bangkok','YYYY-MM-DD'),count(*) filter(where status='ok'),count(*) filter(where status<>'ok')
  from slips where created_at>now()-interval '31 days' and (p_shop is null or shop_id=p_shop) group by 1 $$;
create or replace function admin_totals() returns json language sql as $$
  select json_build_object('users',(select count(*) from users),'credits',(select coalesce(sum(credits),0) from users),
  'pending',(select count(*) from topups where status='pending'),'revenue',(select coalesce(sum(amount),0) from topups where status='approved'),
  'revenue_today',(select coalesce(sum(amount),0) from topups where status='approved' and created_at>=date_trunc('day',now() at time zone 'Asia/Bangkok') at time zone 'Asia/Bangkok')) $$;
-- ตั้งแอดมินคนแรก: update users set role='admin' where username='ยูสเซอร์ของคุณ';

-- ===== v3: กระเป๋าเงิน + แพ็กเกจหมดอายุ + หน้าแรก =====
alter table users add column if not exists wallet numeric default 0;
alter table users add column if not exists credits_expires_at timestamptz;
alter table packages add column if not exists duration_days int default 30;
alter table packages add column if not exists name_en text;
create table if not exists wallet_logs(id bigserial primary key,user_id uuid references users on delete cascade,delta numeric,reason text,created_at timestamptz default now());
alter table wallet_logs enable row level security;
insert into settings values('logo_url',''),('site_name','SlipCheck'),('contact_line',''),('contact_phone',''),('contact_email',''),('contact_facebook',''),('guide_steps','') on conflict do nothing;

create or replace function add_wallet(p_uid uuid,p_delta numeric,p_reason text) returns numeric language plpgsql as $$
declare w numeric; begin
  update users set wallet=coalesce(wallet,0)+p_delta where id=p_uid and coalesce(wallet,0)+p_delta>=0 returning wallet into w;
  if w is not null then insert into wallet_logs(user_id,delta,reason) values(p_uid,p_delta,p_reason); end if;
  return w; end $$;

-- ตัดเครดิต 1 (ใช้ได้เฉพาะเมื่อยังไม่หมดอายุ)
create or replace function use_credit(p_uid uuid) returns int language plpgsql as $$
declare c int; begin
  update users set credits=credits-1 where id=p_uid and credits>=1 and (credits_expires_at is null or credits_expires_at>now()) returning credits into c;
  return c; end $$;

-- ซื้อแพ็กเกจจากกระเป๋า: สะสมเครดิต + ต่ออายุวันต่อท้าย (duration_days=0 = ไม่หมดอายุ)
create or replace function buy_package(p_uid uuid,p_pkg uuid) returns json language plpgsql as $$
declare k packages%rowtype; u users%rowtype; base timestamptz; ex timestamptz; cr int; w numeric; begin
  select * into k from packages where id=p_pkg and active;
  if not found then return json_build_object('ok',false,'error','package'); end if;
  select * into u from users where id=p_uid for update;
  if not found or u.is_banned then return json_build_object('ok',false,'error','user'); end if;
  if coalesce(u.wallet,0)<k.price then return json_build_object('ok',false,'error','insufficient','shortfall',k.price-coalesce(u.wallet,0)); end if;
  cr:=coalesce(u.credits,0);
  if u.credits_expires_at is not null and u.credits_expires_at<=now() then
    if cr>0 then insert into credit_logs(user_id,delta,reason) values(p_uid,-cr,'เครดิตหมดอายุ'); end if;
    cr:=0; base:=now();
  else base:=coalesce(u.credits_expires_at,now()); end if;
  ex:=case when coalesce(k.duration_days,0)>0 then base+(k.duration_days||' days')::interval else null end;
  w:=coalesce(u.wallet,0)-k.price;
  update users set wallet=w,credits=cr+k.credits,credits_expires_at=ex where id=p_uid;
  insert into wallet_logs(user_id,delta,reason) values(p_uid,-k.price,'ซื้อแพ็กเกจ: '||k.name);
  insert into credit_logs(user_id,delta,reason) values(p_uid,k.credits,'ซื้อแพ็กเกจ: '||k.name);
  return json_build_object('ok',true,'wallet',w,'credits',cr+k.credits,'expires_at',ex,'name',k.name); end $$;

-- ===== v3.1: กันสลิปเติมเงินซ้ำ =====
alter table topups add column if not exists qr_hash text;
create unique index if not exists topups_qr_uq on topups(qr_hash) where qr_hash is not null and status in ('pending','approved');
