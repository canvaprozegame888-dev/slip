# วิธีติดตั้ง SlipCheck บน Plesk (paliw.shop)

1. **ฐานข้อมูล**: เปิด Supabase → SQL Editor → รันไฟล์ `supabase.sql` (รันซ้ำได้) และ `update-sql.sql`
2. **อัปโหลด**: แตกซิปทับในโฟลเดอร์ `/nocheck` (ซิปนี้ไม่มี `.env` ให้ใช้ `.env` เดิมบนเซิร์ฟเวอร์)
   ค่าใน `.env` ที่ต้องมี: `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `JWT_SECRET`, `SLIP_API_URL`, `SLIP_API_KEY`
3. **ตั้งค่า Node.js ใน Plesk**: กำหนด Application root เป็น `/var/www/vhosts/paliw.shop/nocheck` และ Application startup file เป็น `app.js`
4. **ติดตั้งและ build** (เทอร์มินัล):
   ```bash
   cd /var/www/vhosts/paliw.shop/nocheck
   npm install
   npm run build
   mkdir -p tmp && touch tmp/restart.txt
   ```
   ตาราง Route ตอน build ต้องเห็น `/`, `/login`, `/dashboard`, `/admin` และ `/api/...`
5. **ตั้งแอดมินคนแรก**: สมัครสมาชิกในเว็บก่อน แล้วรันใน Supabase SQL Editor
   ```sql
   update users set role='admin' where username='ยูสเซอร์ของคุณ';
   ```
6. **ตั้งค่าระบบ**: เข้าเว็บด้วยแอดมิน → ตั้งค่าระบบ → ใส่พร้อมเพย์/ชื่อบัญชีรับเงิน ชื่อเว็บ ช่องทางติดต่อ
7. **เชื่อม LINE**: สมาชิกวาง Channel ID/Secret/Token ที่เมนู "ตั้งค่าบอท LINE" แล้วคัดลอก Webhook URL ของร้านจากหน้านั้น (รูปแบบ `https://paliw.shop/api/webhook/line/<shop-id>`) ไปวางใน LINE Developers → เปิด Use webhook → Verify ห้ามใช้ `/webhook.php`

> แก้โค้ดหรือ `.env` ทุกครั้งต้อง `npm run build` (ถ้าแก้โค้ด) และ Restart App ใหม่ใน Plesk
