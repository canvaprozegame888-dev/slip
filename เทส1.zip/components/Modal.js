'use client';
export default function Modal({title,onClose,children,wide}){
  return <div className="modal-bg" onMouseDown={e=>e.target===e.currentTarget&&onClose()}>
    <div className="modal" style={wide?{width:'min(720px,94vw)'}:undefined} role="dialog" aria-modal="true">
      <div className="mh"><h3>{title}</h3><button type="button" className="lnk" onClick={onClose} aria-label="close">✕</button></div>
      {children}
    </div>
  </div>;
}
