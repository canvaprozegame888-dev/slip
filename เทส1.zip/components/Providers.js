'use client';import {createContext,useContext,useEffect,useRef,useState} from 'react';import {D} from '@/lib/i18n';
const Ctx=createContext({lang:'th',setLang:()=>{},t:k=>k});
export const useT=()=>useContext(Ctx);
export function Providers({children}){
  const [lang,setL]=useState('th');
  useEffect(()=>{try{const l=localStorage.getItem('lang');if(l==='en'||l==='th')setL(l)}catch{}},[]);
  useEffect(()=>{document.documentElement.lang=lang},[lang]);
  const setLang=l=>{setL(l);try{localStorage.setItem('lang',l)}catch{}};
  const t=k=>D[lang][k]??D.th[k]??k;
  return <Ctx.Provider value={{lang,setLang,t}}>{children}</Ctx.Provider>;
}
export function ThemeSwitch(){
  const {t}=useT(),[dark,setDark]=useState(false);
  useEffect(()=>{setDark(document.documentElement.dataset.theme==='dark')},[]);
  const flip=()=>{const n=!dark;setDark(n);document.documentElement.dataset.theme=n?'dark':'light';try{localStorage.setItem('theme',n?'dark':'light')}catch{}};
  return <button type="button" className={'sw2'+(dark?' on':'')} role="switch" aria-checked={dark} aria-label={t('theme')} title={t('theme')} onClick={flip}><i>{dark?'☾':'☀'}</i></button>;
}
export function LangSwitch(){const {lang,setLang}=useT();return <div className="lang"><button type="button" className={lang==='th'?'on':''} onClick={()=>setLang('th')}>TH</button><button type="button" className={lang==='en'?'on':''} onClick={()=>setLang('en')}>EN</button></div>}
export function Brand({big}){
  const [s,setS]=useState(null);
  useEffect(()=>{fetch('/api/public').then(x=>x.json()).then(setS).catch(()=>setS({}))},[]);
  const name=s?.site_name||'SlipCheck';
  if(s?.logo_url)return <span className={'brand-l'+(big?' big':'')}><img src={s.logo_url} alt={name} referrerPolicy="no-referrer"/></span>;
  return <span className={'wm'+(big?' big':'')}>{name}</span>;
}
export function Reveal({children,d=0,as:T='div',className='',...p}){
  const ref=useRef(null);const [on,setOn]=useState(false);
  useEffect(()=>{const el=ref.current;if(!el)return;if(!('IntersectionObserver' in window)){setOn(true);return}
    const o=new IntersectionObserver(([e])=>{if(e.isIntersecting){setOn(true);o.disconnect()}},{threshold:.12,rootMargin:'0px 0px -40px 0px'});o.observe(el);return()=>o.disconnect()},[]);
  return <T ref={ref} className={'rv '+(on?'in ':'')+className} style={{transitionDelay:d+'ms'}} {...p}>{children}</T>;
}
export function Mascot({className=''}){
  return <svg className={'mascot '+className} viewBox="0 0 240 280" fill="none" stroke="currentColor" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" role="img" aria-label="SlipCheck mascot">
    <ellipse cx="120" cy="266" rx="62" ry="7" fill="currentColor" stroke="none" opacity=".12"/>
    <g className="mb"><path d="M52 34h136a8 8 0 0 1 8 8v186l-15-11-14 11-15-11-15 11-15-11-15 11-15-11-15 11-15-11-15 11-14-11-15 11V42a8 8 0 0 1 8-8z" style={{fill:'var(--bg)'}}/>
    <path d="M78 66h84M90 84h60" opacity=".35"/>
    <circle cx="94" cy="124" r="7" fill="currentColor" stroke="none"/><circle cx="146" cy="124" r="7" fill="currentColor" stroke="none"/>
    <circle cx="84" cy="144" r="8" fill="currentColor" stroke="none" opacity=".12"/><circle cx="156" cy="144" r="8" fill="currentColor" stroke="none" opacity=".12"/>
    <path d="M104 144q16 16 32 0"/>
    <path d="M52 140q-26 6-30 28" className="arm"/><path d="M188 140q22-14 36-44" className="arm2"/>
    <circle cx="206" cy="66" r="26" fill="currentColor" stroke="none"/><path d="M194 66l9 9 17-19" style={{stroke:'var(--bg)'}} strokeWidth="6"/>
    <path d="M84 192h72" opacity=".35"/></g></svg>;
}
