'use client';import Link from 'next/link';import {useT,ThemeSwitch,LangSwitch,Brand,Reveal,Mascot} from './Providers';import DemoNotice from './DemoNotice';
const nf=x=>Number(x||0).toLocaleString();
export default function Landing({s,packages,loggedIn}){
  const {t,lang}=useT();
  const contacts=[['LINE',s.contact_line,/^https?:/i.test(s.contact_line)?s.contact_line:s.contact_line.startsWith('@')?'https://line.me/R/ti/p/'+encodeURIComponent(s.contact_line):null],
    [lang==='en'?'Phone':'โทร',s.contact_phone,'tel:'+s.contact_phone.replace(/\s/g,'')],['Email',s.contact_email,'mailto:'+s.contact_email],['Facebook',s.contact_facebook,/^https?:/i.test(s.contact_facebook)?s.contact_facebook:null]].filter(c=>c[1]);
  const feats=[1,2,3,4,5,6];
  return <div className="lp">
    <DemoNotice/>
    <header className="nav"><div className="wrap"><Link href="/"><Brand/></Link>
      <nav><a href="#features">{t('nav_features')}</a><a href="#steps">{t('nav_steps')}</a><a href="#pricing">{t('nav_pricing')}</a><a href="#contact">{t('nav_contact')}</a></nav>
      <div className="r"><LangSwitch/><ThemeSwitch/>{loggedIn?<Link className="btn" href="/dashboard">{t('nav_dash')}</Link>:<><Link className="btn sec" href="/login">{t('nav_login')}</Link><Link className="btn" href="/login?mode=register">{t('nav_register')}</Link></>}</div></div></header>
    <section className="hero2 sec"><div className="wrap">
      <Reveal><div className="tag">{t('hero_tag')}</div><h1>{t('hero_h')}</h1><p className="lead">{t('hero_p')}</p>
        <div className="acts"><Link className="btn lg" href={loggedIn?'/dashboard':'/login?mode=register'}>{loggedIn?t('nav_dash'):t('hero_cta')}</Link><a className="btn sec lg" href="#pricing">{t('hero_cta2')}</a></div>
        <div className="note">{t('hero_note')}</div></Reveal>
      <Reveal d={150}><Mascot/></Reveal></div></section>
    <section className="sec" id="features"><div className="wrap"><Reveal><div className="tag">{t('f_tag')}</div><h2>{t('f_h')}</h2></Reveal>
      <Reveal className="fg">{feats.map(i=><div key={i}><b>0{i}</b><h3>{t('f'+i+'t')}</h3><p>{t('f'+i+'d')}</p></div>)}</Reveal></div></section>
    <section className="sec" id="steps"><div className="wrap"><Reveal><div className="tag">{t('s_tag')}</div><h2>{t('s_h')}</h2></Reveal>
      <div className="st3">{[1,2,3].map(i=><Reveal key={i} d={i*120}><div className="n">{i}</div><h3>{t('s'+i+'t')}</h3><p>{t('s'+i+'d')}</p></Reveal>)}</div></div></section>
    <section className="sec" id="pricing"><div className="wrap"><Reveal><div className="tag">{t('p_tag')}</div><h2>{t('p_h')}</h2></Reveal>
      <Reveal>{packages.length?<div className="tw"><table className="pt2"><thead><tr><th>{t('p_name')}</th><th>{t('p_price')}</th><th>{t('p_credits')}</th><th>{t('p_days')}</th><th>{t('p_rate')}</th></tr></thead><tbody>
        {packages.map(p=><tr key={p.id}><td><b>{lang==='en'&&p.name_en?p.name_en:p.name}</b></td><td className="pr">฿{nf(p.price)}</td><td>{nf(p.credits)} {t('p_cr')}</td><td>{p.duration_days>0?`${p.duration_days} ${t('p_day')}`:t('p_never')}</td><td className="mut">{(p.price/p.credits).toFixed(2)} {t('p_unit')}</td></tr>)}</tbody></table></div>:<p className="mut">{t('p_none')}</p>}
        <p className="mut sm" style={{marginTop:14}}>{t('p_note')}</p>
        {!loggedIn&&<p><Link className="btn" href="/login?mode=register">{t('p_buy')}</Link></p>}</Reveal></div></section>
    <section className="sec" id="contact"><div className="wrap"><Reveal><div className="tag">{t('c_tag')}</div><h2>{t('c_h')}</h2></Reveal>
      <Reveal className="ct">{contacts.length?contacts.map(([l,v,h])=>h?<a key={l} href={h} target={h.startsWith('http')?'_blank':undefined} rel="noopener noreferrer"><span>{l}</span><b>{v}</b></a>:<div className="c" key={l}><span>{l}</span><b>{v}</b></div>):<div className="c"><b>{t('c_none')}</b></div>}</Reveal></div></section>
    <footer className="foot"><div className="wrap"><span>© {new Date().getFullYear()} {s.site_name||'SlipCheck'}</span><span>{t('foot')}</span></div></footer>
  </div>;
}
