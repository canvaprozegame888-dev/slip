'use client';

export default function DemoNotice({children='ข้อมูลทั้งหมดเป็นข้อมูลจำลอง การเติมเงินและการซื้อแพ็กเกจไม่มีการเรียกเก็บเงินจริง'}){
  if(process.env.NEXT_PUBLIC_DEMO_MODE!=='true')return null;
  return <div role="status" style={{margin:'12px auto',padding:'10px 14px',borderRadius:10,background:'#fff4d6',color:'#704900',fontSize:14,maxWidth:1100}}>
    โหมดทดลองใช้ — {children}
  </div>;
}
