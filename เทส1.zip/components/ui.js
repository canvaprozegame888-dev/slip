'use client';import {useEffect,useState} from 'react';
export function useApi(url){const [d,setD]=useState(null);const load=()=>fetch(url).then(x=>x.ok?x.json():null).then(setD);useEffect(()=>{load()},[url]);return [d,load]}
export const api=(url,method,body)=>fetch(url,{method,body:JSON.stringify(body)}).then(x=>x.json().catch(()=>({})));
export const dt=t=>new Date(t).toLocaleString('th-TH',{dateStyle:'short',timeStyle:'short'});
export const n=x=>Number(x||0).toLocaleString();
export const day=t=>t?new Date(t).toLocaleDateString('th-TH',{dateStyle:'medium'}):null;
export const Stat=({t,v,u,sub,tone})=><div className="card stat"><div className="mut">{t}</div><div className={'big '+(tone||'')}>{v}{u&&<small> {u}</small>}</div><div className="mut sm">{sub||'\u00a0'}</div></div>;
export const Pill=({s})=>{const m={ok:['สำเร็จ','ok'],fail:['ไม่สำเร็จ','fail'],approved:['อนุมัติแล้ว','ok'],pending:['รอตรวจสอบ','wait'],rejected:['ปฏิเสธ','fail']}[s]||[s,'wait'];return <span className={'pill '+m[1]}>{m[0]}</span>};
export function Chart({data,title,sub}){
  const max=Math.max(1,...data.map(x=>x.ok+x.fail)),h=130;
  return <div className="card"><div className="chead"><div><h3>{title}</h3><div className="mut sm">{sub}</div></div><div className="leg"><i style={{background:'var(--fg)'}}/>สำเร็จ <i style={{background:'var(--fail)'}}/>ไม่สำเร็จ</div></div>
    <svg viewBox={`0 0 ${data.length*40} 160`} className="chart">{data.map((x,i)=>{const o=x.ok/max*h,f=x.fail/max*h;return <g key={x.d}><title>{`${x.d}: สำเร็จ ${x.ok} · ไม่สำเร็จ ${x.fail}`}</title><rect x={i*40+8} y={h-o-f+6} width="24" height={f} style={{fill:'var(--fail)'}}/><rect x={i*40+8} y={h-o+6} width="24" height={o} style={{fill:'var(--fg)'}}/><text x={i*40+20} y="154" fontSize="9" textAnchor="middle" style={{fill:'var(--mut)'}}>{x.d.slice(5)}</text></g>})}</svg></div>;
}
export const Empty=({t})=><p className="mut" style={{padding:'18px 4px'}}>{t}</p>;
