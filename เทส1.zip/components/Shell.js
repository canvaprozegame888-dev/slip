'use client';import Link from 'next/link';import {usePathname,useRouter} from 'next/navigation';import {useEffect,useState} from 'react';import {useT,ThemeSwitch,LangSwitch,Brand} from './Providers';import DemoNotice from './DemoNotice';
const U=[['g_home',[['/dashboard','m_dash','▦']]],['g_use',[['/history','m_hist','☑'],['/wallet','m_wallet','฿'],['/credits','m_pkg','▣']]],['g_set',[['/settings','m_set','⚙'],['/guide','m_guide','?']]]];
const A=[['ผู้ดูแลระบบ',[['/admin','ภาพรวมระบบ','▦'],['/admin/users','สมาชิก','☺'],['/admin/topups','รายการเติมเงิน','฿'],['/admin/packages','แพ็กเกจ','▤'],['/admin/guide','คู่มือเชื่อมต่อ','?'],['/admin/settings','ตั้งค่าระบบ','⚙']]]];
const nf=x=>Number(x||0).toLocaleString();
export default function Shell({children}){
  const p=usePathname(),r=useRouter(),{t}=useT(),[me,setMe]=useState(null),[open,setOpen]=useState(false);
  const load=()=>fetch('/api/me').then(x=>x.status===401?r.push('/login'):x.json().then(setMe));
  useEffect(()=>{load();setOpen(false)},[p]);
  useEffect(()=>{addEventListener('credits',load);return()=>removeEventListener('credits',load)},[]);
  if(!me)return null;
  const nav=me.role==='admin'?[...U,...A]:U;
  const out=async()=>{await fetch('/api/auth',{method:'POST',body:JSON.stringify({mode:'logout'})});r.push('/login')};
  return <div className="shell">
    <aside className={open?'open':''}><Link href="/" className="brand" style={{display:'block'}}><Brand/></Link>
      {nav.map(([h,it])=><div key={h}><div className="gh">{t(h)}</div>{it.map(([href,l,i])=><Link key={href} href={href} className={'mi'+(p===href||(href.split('/').length>2&&p.startsWith(href))?' on':'')}><span>{i}</span>{t(l)}</Link>)}</div>)}
    </aside>
    <div className="main">
      <div className="top"><button className="burger" onClick={()=>setOpen(!open)}>☰</button><div className="sp"/>
        <Link href="/wallet" className="chip">{t('wallet')} <b>฿{nf(me.wallet)}</b></Link>
        <Link href="/credits" className={'chip'+(me.credits>0?' ok':' bad')}>{t('credit')} <b>{nf(me.credits)}</b></Link>
        <LangSwitch/><ThemeSwitch/>
        <div className="usr"><i>{me.username[0].toUpperCase()}</i><span>{me.username}</span><button className="lnk" onClick={out}>{t('logout')}</button></div></div>
      <div className="page"><DemoNotice/>{children}</div>
    </div></div>;
}
